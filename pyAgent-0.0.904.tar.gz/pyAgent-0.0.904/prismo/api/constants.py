#!/usr/bin/env python
__copyright__ = """
* Copyright (c) 2018 Prismo Systems . All rights reserved.
*
"""

__author__ = 'Ramesh Mani'

HTTP_CORRELATION_HEADER_KEY = 'PRISMO_CORR_ID'
HTTP_CORRELATION_CALLER_TXN_ID = 'PRISMO_CORR_CALLER_ID'
HTTP_CORRELATION_SEQUENCE = 'PRISMO_CORR_SEQ'
EXIT_POINT_ID = 'exit_point_id'
CALLER_EXIT_POINT_ID = 'caller_exit_point_id'
