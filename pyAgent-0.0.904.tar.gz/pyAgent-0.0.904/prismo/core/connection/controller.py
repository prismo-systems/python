import socket


class AgentRegistration(object):

    def __init__(self, agent_id, address, collector_id, host, port, procmon_port):
        self.agent_id = agent_id
        self.address = address
        self.collector_id = collector_id
        self.host = host
        self.port = port
        self.procmon_port = procmon_port


class ControllerConnection(object):
    conn = None
    agent = None
    address = None
    port = None
    agent_registration = None
    cert_file = None
    logger = None

    def __init__(self, agent, agent_registration, cert_file, address, port=7820):
        ControllerConnection.agent = agent
        ControllerConnection.address = address
        ControllerConnection.port = int(port)
        ControllerConnection.cert_file = cert_file
        ControllerConnection.agent_registration = agent_registration
        if agent:
            ControllerConnection.logger = agent.get_logger(__name__)

    @classmethod
    def connect(cls):
        import ssl
        try:
            if ControllerConnection.logger:
                ControllerConnection.logger.debug('cert file: ' + str(ControllerConnection.cert_file))
            sock = socket.socket(socket.AF_INET)
            cls.conn = ssl.wrap_socket(sock, certfile=ControllerConnection.cert_file)
        except Exception as e:
            if ControllerConnection.logger:
                ControllerConnection.logger.debug('Exception ' + str(e))
            return False

        try:
            cls.conn.connect((cls.address, cls.port))
            if ControllerConnection.logger:
                ControllerConnection.logger.debug('Succesfully connected to controller');
        except Exception as ee:
            if ControllerConnection.logger:
                ControllerConnection.logger.debug('Exception ' + str(ee))
            return False
        return True

    @classmethod
    def get_ip(cls):
        try:
            ip = cls.conn.getsockname()[0]
        except Exception as e:
            ip = '127.0.0.1'
        return ip

    @classmethod
    def node_req(cls):
        s = '{"node_type":"' + "AppAgent" + \
               '","id":"' + \
               '","address":"' + cls.get_ip() + \
               '","windows":false' + \
               ',"version":"' + \
               '","allow_upgrade":false' + \
               '}'
        return str.encode(s)

    @classmethod
    def register_agent(cls):
        # print 'Sending agent registration to controller'
        raw_registration = ""
        agent_rec = None
        if ControllerConnection.logger:
            ControllerConnection.logger.debug('Sending msg to controller :' + str(cls.node_req()))
        try:
            cls.conn.sendall(cls.node_req())
            s = str(cls.conn.recv(), 'utf-8')
            while s:
                raw_registration += s
                s = str(cls.conn.recv(), 'utf-8')
            try:
                agent_rec = cls.process_agent_record(raw_registration)
            except Exception as e:
                if ControllerConnection.logger:
                    ControllerConnection.logger.debug('Failed to get collector address! -' + str(e))
        except Exception as err:
            if ControllerConnection.logger:
                ControllerConnection.logger.debug('Failed to send registration info to controller -' + str(err))

        return agent_rec

    @classmethod
    def close_connection(cls):
        cls.conn.close()

    @classmethod
    def process_agent_record(cls, raw_registration):
        if ControllerConnection.logger:
            ControllerConnection.logger.debug(raw_registration)
        import json
        registration = json.loads(raw_registration)
        idx_comment = registration["node_config"].find('{')
        if idx_comment > 0:
            stripped_registration = registration["node_config"][idx_comment:]
            node_config = json.loads(stripped_registration)
        else:
            node_config_str = registration["node_config"]
            node_config = json.loads(node_config_str)
        collector_id = node_config['collector']["id"]
        host = node_config['collector']["host"]
        port = node_config['collector']["port"]
        agent_id = node_config['agent']["id"]
        address = node_config['agent']["host"]
        procmon_port = node_config['collector']["procmon_port"]
        agent_rec = AgentRegistration(agent_id, address, collector_id, host, port, procmon_port)
        if ControllerConnection.logger:
            ControllerConnection.logger.debug('Collector:' + agent_rec.collector_id + '  host:' + agent_rec.host +
                                              ' Agent ID:' + agent_rec.agent_id + "address: " + address)
        return agent_rec


def main():
    cert_file = "C:\\src\\bitbucket\\agent-aug9\\pos\\src\\appagent\pyAgent\\prismo\\config\\certfile.crt"
    cc = ControllerConnection(None, None, cert_file, '10.0.17.11', 7820)
    ok = cc.connect()
    if ok:
        agent_rec = ControllerConnection.register_agent()
        if agent_rec:
            print ('success')
        else:
            print ('Failed to register')
    else:
        print ('Failed connection')


if __name__ == '__main__':
    main()
