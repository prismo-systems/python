#!/usr/bin/env python
import importlib
import traceback
__copyright__ = """
* Copyright (c) 2018 Prismo Systems . All rights reserved.
*
"""

__author__ = 'Ramesh Mani'
import builtins as __builtin__
import sys
from datetime import datetime
from prismo.util.pattern import Singleton
from prismo.constants import PRINT_PREFIX, PRINT_PREFIX_DEBUG, MODULE, CLASS, NAME, METHOD, PROBE, PRINT_PREFIX_TRACE,SIG_TYPE
from prismo.core.probes import ProbeCodeStub
from prismo.core.transaction import PrismoThreadLocalStack, MethodContext
import logging
import threading
import os


# created by agent
# has the config and (a reference to the agent?)
class ProbeAdministrator(Singleton):
    def __init__(self, agent, instrumentation_config):
        self.agent = agent
        self.logger = agent.get_logger(__name__)
        # This has the entire instrumentation config
        self.instrumentation_config = instrumentation_config
        #
        # One per loaded probes.
        # key = probe name, value = ProbeDefinitionInstance
        self.probe_definition_instances = {}
        #
        # One per instrumented method
        # key = module#<module>|class#<class>|method#<method>, value = AggregateInstructionInstance
        self.aggregate_instruction_instances = {}
        self.instruction_lock = threading.RLock()

        # set the agent in the MethodContext here
        MethodContext.agent = agent

    def __load_probe(self, probe_name):
        # this will load the probe
        probe_definition = self.instrumentation_config.get_probe_definition(probe_name)
        if probe_definition is None:
            probe_definition_instance = ProbeDefinitionInstance.default_instance(self.agent, probe_name)
            self.logger.warn(' Using ProbeCodeStub as probe definition was not found! - ' + probe_name)
        else:
            # we need a way to add the parameters in the probe definition into the ProbeDefinitionInstance. It
            # has a method, but we need to iterate thru the whole map and separate them.. maybe
            # do it while loading the config file itself. for now passing an empty map
            probe_definition_instance = ProbeDefinitionInstance(self.agent, probe_name, probe_definition[MODULE],
                                                                probe_definition[CLASS], {})

        self.probe_definition_instances[probe_name] = probe_definition_instance
        probe_definition_instance.load_probe()

    def get_probe(self, probe_name):
        if (self.probe_definition_instances.get(probe_name) is None or
                not self.probe_definition_instances[probe_name].is_loaded()):
            self.__load_probe(probe_name)
        return self.probe_definition_instances[probe_name]

    def should_transform_module(self, module_name):
        # check with config
        if self.instrumentation_config.should_skip_module(module_name):
            return False
        return self.instrumentation_config.matches_module_instrumentation(module_name)

    def has_instrumentation_instructions(self):
        return self.instrumentation_config.has_instrumentation_instructions()

    def get_instruction_names(self):
        return self.instrumentation_config.get_instruction_names()

    def get_instruction(self, name):
        return self.instrumentation_config.get_instruction(name)

    # should check the instruction for the module and class as well.
    def should_skip_instruction(self, name):
        if self.instrumentation_config.should_skip_instruction(name):
            return True
        instruction = self.get_instruction(name)
        if self.instrumentation_config.should_skip_module(instruction.get(MODULE)):
            return True
        if self.instrumentation_config.should_skip_class(instruction.get(CLASS)):
            return True
        return False

    # TODO
    # TODO name alone is not good enough when instruction[BASE]=True. But BASE is not fully supported yet
    # TODO
    def is_instruction_instantiated(self, name):
        instruction = self.get_instruction(name)
        key = AggregateInstructionInstance.get_aggregate_instruction_instance_key(instruction)
        if key in self.aggregate_instruction_instances:
            aggregate_instruction_instance = self.aggregate_instruction_instances.get(key)
            if aggregate_instruction_instance.contains_instruction(instruction):
                return True
            else:
                return False
        return False

    # Always return the current value from the list
    def add_aggregate_instruction(self, key, aggregate):
        # lock and insert.
        self.instruction_lock.acquire()
        # print ('Lock proibeadmin List:' + key)
        # check if it already exists
        if self.aggregate_instruction_instances.get(key) is None:
            self.aggregate_instruction_instances[key] = aggregate
        self.instruction_lock.release()
        # print ('UnLock proibeadmin List:' + key)

        return self.aggregate_instruction_instances.get(key)

    def get_aggregate_instruction(self, key):
        return self.aggregate_instruction_instances.get(key)


# created during agent init
class ModuleAdministrator (Singleton):
    def __init__(self, agent, probe_admin):
        self._agent = agent
        self.logger = agent.get_logger(__name__)
        self._loaded_modules = set()
        # this count is purely based on what sys.modules has
        self.module_count = 0
        self.probe_admin = probe_admin

    # The import hook is called every time the "import" statement is used. This ensures that the
    # module is instrumented only once and not for every subsequent import of this module
    def has_loaded_modules(self):
        sys_modules_count = len(sys.modules.keys())
        if sys_modules_count != self.module_count:
            self.module_count = sys_modules_count
            return True
        else:
            return False

    # check based start of name.. submodules are loaded inside the package
    # __import__(name, globals=None, locals=None, fromlist=(), level=0)
    # __import__('spam.ham', globals(), locals(), ['eggs', 'sausage'], 0)
    def should_transform(self, module_name_base, from_list, imported_module):
        current_count = len(self._loaded_modules)

        # check the modules we loaded in this call... use the parameters to deduce them
        # 1) see 1st parameter -  'name'
        module_names = []
        module_name = ''
        if module_name_base is not None:
            subpackages = str(module_name_base).split('.')
            for name in subpackages:
                module_name = '.'.join([module_name, name])
                module_name = module_name.strip('.').strip()
                self._loaded_modules.add(module_name)
                module_names.append(module_name)
        # check what we have so far
        # if we have seen all these module names before then they were loaded prior to this call,
        # so we don't need to match against  instrumentation instructions.
        if current_count != len(self._loaded_modules):
            for module_str in module_names:
                # print ('module-check:' + module_str)
                if self.logger.isEnabledForTrace():
                    self.logger.trace("module-check:" + module_str)
                if self.probe_admin.should_transform_module(module_str):
                    return True

        # 1) see 3rd parameter -  imported_module.__name__

        # print ('module.__name__' + imported_module.__name__)
        module_names = []
        module_name = ''
        if imported_module is not None and imported_module.__name__ is not None:
            subpackages = str(imported_module.__name__).split('.')
            for name in subpackages:
                module_name = '.'.join([module_name, name])
                module_name = module_name.strip('.').strip()
                self._loaded_modules.add(module_name)
                module_names.append(module_name)
        # check what we have so far
        # if we have seen all these module names before then they were loaded prior to this call,
        # so we don't need to match against  instrumentation instructions.
        if current_count != len(self._loaded_modules):
            for module_str in module_names:
                # print ('module-check2:' + module_str)
                if self.logger.isEnabledForTrace():
                    self.logger.trace("module-check2:" + module_str)
                if self.probe_admin.should_transform_module(module_str):
                    return True

        # check the modules we loaded in this call... use the parameters to deduce them
        # 1) see 2nd parameter -  from_list[]
        module_names = []
        module_name_str = module_name_base
        # prefix  imported_module.__name__ as that has package from to the root in nested packages
        if imported_module.__name__ is not None:
            module_name_str = imported_module.__name__

        if from_list is not None and len(from_list) > 0:
            from_list_array = str(from_list).strip('()').split(',')
            for name in from_list_array:
                module_name = '.'.join([module_name_str, name.strip(' \'')])  # join on with the module_name_base
                module_name = module_name.strip('.').strip()
                self._loaded_modules.add(module_name)
                module_names.append(module_name)

        # check what we have so far
        # if we have seen all these module names before then they were loaded prior to this call,
        # so we don't need to match against  instrumentation instructions.
        if current_count != len(self._loaded_modules):
            for module_str in module_names:
                # print ('module-check3:' + module_str)
                if self.logger.isEnabledForTrace():
                    self.logger.trace("module-check3:" + module_str)
                if self.probe_admin.should_transform_module(module_str):
                    return True

        return False

    def get_loaded_module_names(self):
        return self._loaded_modules


# created during agent init
class Instrumentation (Singleton):

    # handle to the system defined import definition
    _system_import_definition__ = None
    # track loaded modules
    _module_admin = None
    _probe_admin = None
    _agent = None
    _logger = None
    # During nested import statements, the import hook will be
    # be called recursively for the module load event, but it will not
    # find the class or method it needs to instrument since
    # it may not have been loaded yet.
    # so we need to constantly look for it at the end of every module load
    _module_partially_loaded = False
    _recursion_count = 0
    mod_flag = True

    def __init__(self, agent, module_admin, probe_admin):
        Instrumentation._agent = agent
        Instrumentation._module_admin = module_admin
        Instrumentation._probe_admin = probe_admin
        Instrumentation._logger = agent.get_logger(__name__)

    @classmethod
    def is_initialized(cls):
        if cls._system_import_definition__ is None:
            return False
        return True

    @classmethod
    def initialize_import_hook(cls):
        cls._system_import_definition__ = __builtin__.__import__

    @classmethod
    def enable(cls):
        __builtin__.__import__ = cls.__prismo_import__
        if cls._logger.isEnabledFor(logging.DEBUG):
            cls._logger.debug('Prismo import definition hooked ')

    # should disable only for this thread. Use threading.local variable to do this.
    # else it will miss modules loaded by other threads
    @classmethod
    def disable(cls):
        if cls._system_import_definition__ is not None:
            __builtin__.__import__ = cls._system_import_definition__
            if cls._logger.isEnabledFor(logging.DEBUG):
                cls._logger.debug('Disabled import hook')
        else:
            if cls._logger.isEnabledFor(logging.DEBUG):
                cls._logger.debug('Unable to revert import system to original system state')

    #   All parameters are not passed in for every call. Need to check
    # __import__(name, globals=None, locals=None, fromlist=(), level=0)
    @staticmethod
    def __prismo_import__(*args, **kwargs):
        if Instrumentation._system_import_definition__ is not None:
            # global recursion_count
            Instrumentation._recursion_count += 1
            from_list = []
            if len(args) > 3 and args[3] is not None and len(args[3]) > 0:
                from_list = args[3]
                # print ('Not empty ' + str(from_list))
            try:
                # use stack variable to get check count before and after. Not perfect, but better than
                # static as other threads could be loading as well
                module_count_before = len(sys.modules.keys())
                # print ("prismo import system: args - " + str(args) + "  -- kwargs - " + str(kwargs))
                imported_module = Instrumentation._system_import_definition__(*args, **kwargs)
                # print ('Saw import ' + imported_module.__name__)
                module_count_after = len(sys.modules.keys())
                # if Instrumentation._module_admin.has_loaded_modules() or Instrumentation._module_partially_loaded:
                if module_count_before != module_count_after or Instrumentation._module_partially_loaded:
                    # print ('First Level : ' + str(os.getpid()) + imported_module.__name__)
                    if (Instrumentation._module_admin.should_transform(args[0], from_list, imported_module)
                            or Instrumentation._module_partially_loaded):
                        try:
                            # print ('Second Level : ' + str(os.getpid()) + imported_module.__name__)
                            Instrumentation.transform()
                        except Exception as e:
                            if Instrumentation._logger.isEnabledFor(logging.DEBUG):
                                Instrumentation._logger.debug('FAILED TO INSTRUMENT :' + imported_module.__name__ + '\n'
                                                              + str(e))
                return imported_module
            except Exception as e:
                # print("AAAAAAAA------->>>>>" + str(e))
                # traceback.print_exc(file=sys.stdout)
                if Instrumentation._logger.isEnabledFor(logging.DEBUG):
                    Instrumentation._logger.debug('Exception seen loading modules: ' + str(e))
                raise
            finally:
                Instrumentation._recursion_count -= 1
                if Instrumentation._recursion_count == 0:
                    Instrumentation._module_partially_loaded = False
        else:
            Instrumentation._logger.debug('Exception Import hook not initialized')
            # print ('Import hook not initialized')

    # This method is called after every module is loaded and matches the list of modules
    # to be transformed. However this method simply transforms all modules that match any instruction.
    # This call does not take a specific module
    @staticmethod
    def transform():
        if not Instrumentation._probe_admin.has_instrumentation_instructions():
            return
        i = 0
        instruction_names = Instrumentation._probe_admin.get_instruction_names()
        while i < len(instruction_names):
            if not Instrumentation._probe_admin.should_skip_instruction(instruction_names[i]) \
                    and not Instrumentation._probe_admin.is_instruction_instantiated(instruction_names[i]):
                instruction = Instrumentation._probe_admin.get_instruction(instruction_names[i])
                _module = sys.modules.get(instruction.get(MODULE), None)
                if not _module:
                    i += 1
                    continue
                _class = None
                # Instrumentation._logger.info('Instrumentation: Module match -' + _module.__name__)
                if Instrumentation._logger.isEnabledFor(logging.DEBUG):
                    Instrumentation._logger.debug('Instrumentation: Module match -' + _module.__name__)
                if instruction.get(CLASS) != 'None':
                    _class = getattr(_module, instruction[CLASS], None)
                    if not _class:
                        Instrumentation._module_partially_loaded = True
                        i += 1
                        continue
                    else:
                        if Instrumentation._logger.isEnabledFor(logging.DEBUG):
                            Instrumentation._logger.debug('Instrumentation: Class match -' + _class.__name__)
                _method = None

                if _class:
                    _method = getattr(_class, instruction[METHOD], None)
                else:
                    _method = getattr(_module, instruction[METHOD], None)
                if not _method:
                    # should set it for methods as well?
                    Instrumentation._module_partially_loaded = True
                    i += 1
                    continue
                # Instrumentation._logger.info('Instrumentation: Method match -' + _method.__name__)
                if Instrumentation._logger.isEnabledFor(logging.DEBUG):
                    Instrumentation._logger.debug('Instrumentation: Method match -' + _method.__name__)
                Instrumentation.insert_probe(_class, _method, _module, instruction)
                i += 1
            else:
                i += 1

    @staticmethod
    def insert_probe(_class, _method, _module, instruction):
        r"""
        :param _class: target class
        :param _method:
        :param _module:
        :param instruction:
        :return:
        create/find AggregateInstructionInstance
        load/find probe
        create probe instance
        create InstructionInstance with instruction and probe instance
        add to AggregateInstruction
        if aggregate was created just now, then tranform target method
        """
        aggregate_instr_key = AggregateInstructionInstance.get_aggregate_instruction_instance_key(instruction)
        aggregate_instruction = Instrumentation._probe_admin.get_aggregate_instruction(aggregate_instr_key)
        if aggregate_instruction is None:
            aggregate_instruction = AggregateInstructionInstance(aggregate_instr_key, Instrumentation._agent)
            aggregate_instruction = Instrumentation._probe_admin.add_aggregate_instruction(aggregate_instr_key, aggregate_instruction)
            # instrument the method since the AggregateInstructionInstance was created now
            if _class:
                method_code = Instrumentation.transform_method(_class, _method, aggregate_instruction)
                setattr(_class, instruction[METHOD], method_code)
            else:
                method_code = Instrumentation.transform_method(_module, _method, aggregate_instruction)
                setattr(_module, instruction[METHOD], method_code)
        # Update the Aggregate for every probe (instruction) with an
        # InstructionInstance and create the probe (ProbeInstance)

        probe_definition = Instrumentation._probe_admin.get_probe(instruction[PROBE])
        probe_instance = probe_definition.instantiate()  # TODO pass probe parameters here
        instruction_instance = InstructionInstance(instruction, probe_instance, Instrumentation._agent)
        aggregate_instruction.add_instruction_instance(instruction_instance)
        # Instrumentation._logger.info('Instrumentatio
        #
        #
        #
        # n instruction %s succeeded', str(instruction))

        if Instrumentation._logger.isEnabledFor(logging.DEBUG):
            Instrumentation._logger.debug('Instrumentation instruction %s succeeded', str(instruction))

    @staticmethod
    def transform_method(target_class, target_func, aggregate_instruction):
        # this method is never called directly. It will be called by the python interpreter
        # when the target method is called
        def __method_code__(*args, **kwargs):
            if Instrumentation.should_skip(target_class, target_func):
                return target_func(*args, **kwargs)

            function_name = target_class.__name__ + '.' + target_func.__name__
            prismo_stack = None
            context = None
            original_parameters = False    # Allow probes to modify parameters. Reset to True if exceptions in probe
            try:
                # print (PRINT_PREFIX_DEBUG + 'AggregateInstructionInstance -Entering :  %s', str(function_name))
                # should we new MethodContext or create a pool
                method_id = function_name
                context = MethodContext(method_id)
                context.push_params(*args, **kwargs)
                prismo_stack = PrismoThreadLocalStack()
                prismo_stack.push(context)
                aggregate_instruction.enter(context)
                context.set_data('StartTime', str(datetime.utcnow()))
            except Exception as e:
                original_parameters = True
                if Instrumentation._logger.isEnabledFor(logging.DEBUG):
                    Instrumentation._logger.debug('Error in AggregateInstructionInstance.enter for %s ', function_name)
                    Instrumentation._logger.debug('Exception that was raised %s', str(e))
            finally:
                # Call the method that was actually called
                try:
                    if original_parameters:
                        context.ret_val = target_func(*args, **kwargs)
                    else:
                        context.ret_val = target_func(*context.args, **context.kwargs)
                except Exception:
                    context.exception_type, context.exception_value, context.trace_back = sys.exc_info()
            try:
                # print (PRINT_PREFIX_DEBUG + 'AggregateInstructionInstance -Exiting :  %s', str(function_name))
                context.set_data('EndTime', str(datetime.utcnow()))
                aggregate_instruction.exit(context)
                prismo_stack.pop()
            except Exception as e:
                if Instrumentation._logger.isEnabledFor(logging.DEBUG):
                    Instrumentation._logger.debug('Exception in AggregateInstructionInstance - exit for %s ',
                                                  function_name)
                    Instrumentation._logger.debug('Exception that was raised %s', str(e))
            finally:
                if hasattr(context, 'exception_type'):
                    print ('system.py exception -' + str(context.exception_value) + "  " + str(context.trace_back))
                    e = ValueError(context.exception_value)
                    e.__traceback__ = context.trace_back
                    e.type = context.exception_type
                    raise e
                    # raise context.exception_type, context.exception_value, context.trace_back
                else:
                    return context.ret_val

        return __method_code__

    @classmethod
    def should_skip(cls, target_class, target_func):
        # This method returns True when the agent is executing a method, so that its own calls are not traced
        # For now we only use a thread local to mark this in Agent threads
        prismo_stack = PrismoThreadLocalStack()
        return prismo_stack.should_skip()


# called in agent init
class ProcessForkHook:
    def __init__(self):
        pass

    # GUnicorn will start a child process typically by forking the parent based on the number of
    # process stated in the app.yaml. we need this hook to detect the fork so that we can
    # create new connections to the server, manage log files

    # we need to hook the system fork method in a multi process environment (GUnicorn say)
    # we need to re-initialize the connection to the server, create logs based on the PID
    # plus redo some of the config. We know it is a child process since
    # the call to fork() returns 0 (zero) in the child process and non zero in the parent.

    @staticmethod
    def enable(agent):
        _os_mod = sys.modules['os']
        _fork_system_func = getattr(_os_mod, 'fork', None)
        if _fork_system_func:
            hook = ProcessForkHook.get_prismo_hook(agent, _fork_system_func)
            setattr(_os_mod, 'fork', hook)
            # print (PRINT_PREFIX + ' Process fork hooked by Prismo Agent')

    @staticmethod
    def get_prismo_hook(agent, _fork_system_func):
        def function_template(*args, **kwargs):
            ret_val = _fork_system_func(*args, **kwargs)
            try:
                if ret_val == 0:
                    # TODO -- Here we need some work
                    # This is the child process as the return value is zero
                    # rename loggers
                    # reestablish server connection
                    # start services
                    # instrumentation is also disabled for some reason
                    # import os
                    # pid_num = str(os.getpid())
                    # print (PRINT_PREFIX + pid_num + 'Child process forked, log and server connection reestablished')
                    agent.initialize_forked_process()
            except Exception as e:
                str_exc = traceback.format_exc()
                for line in traceback.format_stack():
                    str_exc += line.strip()
                print (PRINT_PREFIX + ' Exception in prismo fork handler hook' + str_exc)
                print (PRINT_PREFIX + 'Exception %s', str(e))
            finally:
                return ret_val

        return function_template


# the key = module#<module>|class#<class>|method#<method>
class AggregateInstructionInstance:
    def __init__(self, aggregate_key, agent):
        self.agent = agent
        self.logger = agent.get_logger(__name__)
        self.aggregate_key = aggregate_key
        self.instruction_instances = []
        self.instructions = {}  # kept only for lookup during contains_instruction. More efficient for lookup
        self.first_instruction = None  # used for populating context with module, class, method info at runtime
        self.lock = threading.RLock()

    # Should move this method to the instruction itself in config.py
    @staticmethod
    def get_aggregate_instruction_instance_key(instruction):
        return 'module#' + instruction[MODULE] + '|class#' + instruction[CLASS] + '|method#' + instruction[METHOD]

    def add_instruction_instance(self, instruction_instance):
        self.lock.acquire()
        # print ('Acquired Lock :' + str(instruction_instance.instruction))
        # check if instruction exists
        if self.instructions.get(instruction_instance.instruction[NAME]) is None:
            self.instruction_instances.append(instruction_instance)
            self.instructions[instruction_instance.instruction[NAME]] = True
            if self.first_instruction is None:
                self.first_instruction = instruction_instance.instruction
        # print ('Un Lock :' + str(instruction_instance.instruction))
        self.lock.release()

    def contains_instruction(self, instruction):
        if self.instructions.get(instruction[NAME]) is None:
            return False
        return True

    def enter(self, method_context):
        # set the context with everything common from the instruction instances
        # get the very first one as all have same module, class and method (this is not runtime module and class
        # but relavent only in Java as we don't support inheritance in the instrumentation in python
        method_context.set_data(MODULE, self.first_instruction[MODULE], True)
        method_context.set_data(METHOD, self.first_instruction[METHOD], True)
        if self.first_instruction.get(CLASS) is not None:
            method_context.set_data(CLASS, self.first_instruction[CLASS], True)
        # print ('Aggregate instruction :' + str(self.aggregate_key))
        for instruction_instance in self.instruction_instances:
            instruction_instance.enter(method_context)

    # need to match the parameters of probe exit
    def exit(self, method_context):
        for instruction_instance in reversed(self.instruction_instances):
            instruction_instance.exit(method_context)


class InstructionInstance:
    def __init__(self, instruction, probe_instance, agent):
        self.instruction = instruction
        # instance of the probe class. All derived from ProbeBase
        self.probe_instance = probe_instance
        self.agent = agent
        self.logger = agent.get_logger(__name__)

    # need to match the parameters of probe enter
    def enter(self, method_context):
        # wrap this in a try block as its executing probe code
        try:
            if self.instruction.get(SIG_TYPE) is not None:
                method_context.set_signature_type(self.instruction.get(SIG_TYPE))
            self.probe_instance.enter(self.instruction, method_context)
        except Exception as e:
            if self.logger.isEnabledForTrace():
                self.logger.trace('Exception executing probe.enter ' + str(self.instruction))
                self.logger.trace(str(e))

    # need to match the parameters of probe exit
    def exit(self, method_context):
        # wrap this in a try block as its executing probe code
        try:
            self.probe_instance.exit(self.instruction, method_context)
        except Exception as e:
            if self.logger.isEnabledForTrace():
                self.logger.trace('Exception executing probe.finish ' + str(self.instruction))
                self.logger.trace(str(e))


class ProbeDefinitionInstance:
    def __init__(self, agent, name, module, clasz, args_map):
        self.agent = agent
        self.name = name
        self.module = module
        self.clasz = clasz
        self.args_map = args_map
        self._code = False
        self.logger = agent.get_logger(__name__)

    def set_parameter(self, arg, val):
        self.args_map[arg] = val

    def is_loaded(self):
        if self._code is not None:
            return True
        else:
            return False

    def load_probe(self):
        # this will load the probe
        try:
            Instrumentation.disable()
            self.logger.info('load probe ' + self.module + '.' + self.clasz)

            # load the probe class
            if not self._code:
                self._code = getattr(importlib.import_module(self.module), self.clasz, False)
                if not self._code:
                    self._code = ProbeCodeStub
                    self.logger.warn('Failed to load probe ' + self.module + '.' + self.clasz)
                    self.logger.warn('Using stubbed probe instead')
        except Exception as e:
            self._code = ProbeCodeStub
            self.logger.warn('Failed to load probe ' + self.module + '.' + self.clasz)
            self.logger.warn('Using stubbed probe instead')
            self.logger.warn(str(e))

        finally:
            Instrumentation.enable()

    # pass instruction to this
    def instantiate(self):
        if self.is_loaded():
            return self._code(self.agent)
        else:
            self.logger.warn('Probe instantiated before it was loaded! Using ProbeCodeStub')
            return ProbeCodeStub()

    @staticmethod
    def default_instance(agent, name):
        return ProbeDefinitionInstance(agent, name, 'prismo.core.probes', 'ProbeCodeStub', None)

