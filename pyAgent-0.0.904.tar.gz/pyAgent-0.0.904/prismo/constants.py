PRINT_PREFIX = 'PRISMO: '
PRINT_PREFIX_DEBUG = 'PRISMO_DEBUG: '
PRINT_PREFIX_TRACE = 'PRISMO_TRACE'
#Path
PYTHONPATH = 'PYTHONPATH'
PYTHONUNBUFFERED = 'PYTHONUNBUFFERED'
PYTHONVERBOSE = 'PYTHONVERBOSE'
PRISMO_LOG_ENVIRONMENT = 'prismo_log_environment'

# command line
OPTION_LIST_SHORT = 'hc:p:d'
OPTION_LIST_LONG = ['help', 'config=', 'probe-config=', ]

#
LOGGER_NAME = []
PYAGENT_CFG = 'PYAGENT_ACFG'  # Path to Agent Config File
PYAGENT_PROBE_CFG = 'CPAGENT_PROBE_CFG'  # Path to Probe Config File

# probe config constants
TYPE_PROBE = "probe"
TYPE_INSTRUCTION = "instruction"
TYPE_SERVICE = "service"
TYPE_SKIP = "skip"
MODULE = "module"
CLASS = "class"
METHOD = "method"
BASE = "base"
NAME = "name"
PROBE = "probe"
SIG_TYPE = "sig_type"
INSTRUMENTATION_INSTRUCTION_KEYWORDS = [TYPE_PROBE, TYPE_INSTRUCTION, MODULE, CLASS, METHOD, BASE, NAME, PROBE, SIG_TYPE]


# DataQueue
MAX_DATA_QUEUE_LENGTH = 1000            # transactions
CONNECTION_RETRY_INTERVAL = 60          # 60 seconds
CONNECTION_STATUS_MONITOR_INTERVAL = 5  # seconds
MSG_INTERVAL = 0.1   # 100 ms
MSG_CHUNK_SIZE = 50  # transactions

DEFAULT_LOG_FILENAME = 'prismo_agent.log'
LOGGING_ROOT = 'prismo'
LOGGING_ROOT_DOT = LOGGING_ROOT + '.'

INVENTORY_SERVICE_INTERVAL_KEY = 'interval_wait'


#  Support for threading is limited in GAE std. This gets defined at startup depending on bootstrapping class
THREAD_CLASS = 'ThreadClass'
THREAD_SUPPORT = {THREAD_CLASS: None}

