#!/usr/bin/env python
__copyright__ = """
* Copyright (c) 2018 Prismo Systems . All rights reserved.
*

"""

__author__ = 'Ramesh Mani'

name = "prismo_agent"
