#!/usr/bin/env python
__copyright__ = """
* Copyright (c) 2018 Prismo Systems . All rights reserved.
*
"""

__author__ = 'Ramesh Mani'
import os
import logging
from google.appengine.api import background_thread

environ = os.environ
theAgent = None
# from prismo.constants import THREAD_CLASS, THREAD_SUPPORT
# THREAD_SUPPORT[THREAD_CLASS] = background_thread


print 'Executing agent init'
try:
    # initialize the threading support in the environment
    from prismo.util.threadimp import ThreadSupport
    ThreadSupport(background_thread.BackgroundThread, False)
    from prismo.pyagent import PyAgent
    # print 'Imported Agent package'
    print 'Thread class :' + ThreadSupport.thread_class.__name__  # THREAD_SUPPORT.get(THREAD_CLASS)
    # global theAgent
    # theAgent = PyAgent()
    app_entity = "Default Entity"
    try:
        from google.appengine.api import app_identity, modules
        projectId = app_identity.get_application_id()
        appName = modules.modules.get_current_module_name()
        org = app_identity.get_service_account_name()
        app_entity = "GAE-Standard|" + projectId + "|" + appName + "|Python|" + org
    except Exception as e:
        projectId = "|Default Project"
        appName = "|Default App"
        org = "|Default Organization"
        app_entity = "Default Platform" + projectId + appName + "|Python" + org

    global theAgent
    theAgent = PyAgent(app_entity)
    module_for_logging = 'prismo.bootstrap'
    # after the module pop above, everything (variable up to this point in the module is null)
    # get the logger again. theAgent stays as it global
    logger = theAgent.get_logger(module_for_logging)
    if logger and logger.isEnabledFor(logging.INFO):
        logger.info('Starting agent services')
    theAgent.start_services()
except Exception as e:
    print 'Exception starting agent. ' + str(e)
