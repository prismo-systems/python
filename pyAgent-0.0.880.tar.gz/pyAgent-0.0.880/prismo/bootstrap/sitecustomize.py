#!/usr/bin/env python
__copyright__ = """
* Copyright (c) 2018 Prismo Systems . All rights reserved.
*
"""

__author__ = 'Ramesh Mani'
import os
import sys

environ = os.environ
theAgent = None
print 'Executing agent init'
if __name__ == 'sitecustomize':
    try:
        # print 'Agent in process'
        sys.path.remove(os.path.dirname(__file__))
        # print 'Removed from path'
    except ValueError:
        print 'Error initializing agent!'

    if sys.modules.pop('sitecustomize', None) is not None:
        import logging
        import imp
        import sys
        import threading
        # from prismo.constants import THREAD_CLASS, THREAD_SUPPORT
        # THREAD_SUPPORT[THREAD_CLASS] = threading.Thread
        try:
            # initialize the threading support in the environment
            from prismo.util.threadimp import ThreadSupport
            ThreadSupport(threading.Thread, True)
            from prismo.pyagent import PyAgent
            # print 'Imported Agent package'
            # global theAgent
            # theAgent = PyAgent()
            app_entity = "Default Entity"
            try:
                import os
                environ = os.environ
                projectId = environ["GOOGLE_CLOUD_PROJECT"]
                appName = environ["GAE_SERVICE"]
                try:
                    org = environ["APP_ORG"]
                except Exception as e:
                    org = "Default Organization"
                app_entity = "GAE-Flex|" + projectId + "|" + appName + "|Python|" + org
            except Exception as e:
                projectId = "|Default Project"
                appName = "|Default App"
                org = "|Default Organization"
                app_entity = "Default Platform" + projectId + appName + "|Python" + org

            global theAgent
            theAgent = PyAgent(app_entity)

            module_for_logging = 'prismo.bootstrap'
            # after the module pop above, everything (variable up to this point in the module is null)
            # get the logger again. theAgent stays as it global
            logger = theAgent.get_logger(module_for_logging)
            if logger and logger.isEnabledFor(logging.DEBUG):
                logger.debug("Successfully removed injected sitecustomize ")
            if logger and logger.isEnabledFor(logging.INFO):
                logger.info('Starting agent services')
            theAgent.start_services()
        except Exception as e:
            print 'Exception starting agent. ' + str(e)
    else:
        # after the module pop above, everything (variable up to this point in the module is null)
        # get the logger again. theAgent stays as it global
        print "Failed to remove injected sitecustomize! "

    logger = None
    if theAgent:
        module_for_logging = 'prismo.bootstrap'
        logger = theAgent.get_logger(module_for_logging)
    if logger and logger.isEnabledFor(logging.DEBUG):
        logger.debug("Locating application sitecustomize ")
    try:
        mod_data = imp.find_module('sitecustomize')
        mod = imp.load_module('sitecustomize', *mod_data)
        sys.modules['sitecustomize'] = mod
        if logger and logger.isEnabledFor(logging.DEBUG):
            logger.debug("Succesfully restored application sitecustomize ")
    except ImportError:
        if logger and logger.isEnabledFor(logging.DEBUG):
            logger.debug("Failed to locate application sitecustomize, if any ")
    except Exception as e:
        if logger:
            logger.error("Exception in loading application sitecustomize")
