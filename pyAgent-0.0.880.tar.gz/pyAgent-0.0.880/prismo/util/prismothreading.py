#!/usr/bin/env python
__copyright__ = """
* Copyright (c) 2018 Prismo Systems . All rights reserved.
*
"""

__author__ = 'Ramesh Mani'

# from threading import Thread
from prismo.constants import THREAD_CLASS, THREAD_SUPPORT

# print 'Threading Support: ' + THREAD_SUPPORT.get(THREAD_CLASS).__name__


# class ThreadSupport(object):
#     thread_class = None
#
#     def __init__(self, thread_class):
#         ThreadSupport.thread_class = thread_class
from prismo.util.threadimp import ThreadSupport


class ThreadBase(ThreadSupport.thread_class):
    supports_py_threads = ThreadSupport.supports_py_threads

    def __init__(self, group=None, target=None, name=None, kwargs=None):
        super(ThreadBase, self).__init__(group=group, target=target, name=name, kwargs=kwargs)


