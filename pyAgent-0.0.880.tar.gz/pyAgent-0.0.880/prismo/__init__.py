#!/usr/bin/env python
__copyright__ = """
* Copyright (c) 2018 Prismo Systems . All rights reserved.
*
"""

__author__ = 'Ramesh Mani'

import os
import errno
import getopt
import sys


environ = os.environ

# should make probes another library that this depends  thru the requirements.


def parse_opts(optlist):
    from prismo.constants import PYAGENT_CFG, PYAGENT_PROBE_CFG
    for opt, args in optlist:
        if opt in ('-h', '--help'):
            print extended_usage()
            return True
        # Add options with both names after this comment
        elif opt in ('-c', '--config'):
            environ[PYAGENT_CFG] = os.path.realpath(os.path.expanduser(args))
        elif opt in ('-p', '--probe-config'):
            environ[PYAGENT_PROBE_CFG] = os.path.realpath(os.path.expanduser(args))
        # Add options with only short names after this comment
        elif opt == '-d':
            # TODO enable debugging
            pass
        # Add options with only long names after this comment
        else:
            print_usage()
            return True
    return False


def print_usage():
    from prismo.constants import PRINT_PREFIX
    print PRINT_PREFIX + '\n' \
        'For default usage: prismopy <your existing command>\n ' \
        'For advanced usage prismopy -h/--help'


def extended_usage():
    from prismo.constants import PRINT_PREFIX
    print PRINT_PREFIX + '\n' \
        'For default usage                   :  prismopy <your existing command>\n ' \
        'Advanced usage                      :  prismopy <options> <your existing command>\n ' \
        'Available options \n' \
        '-h/--help                           :  Gets you back to this message \n' \
        '-c/--config <file>                  :  Custom agent configuration file \n' \
        '-p/--probe_config config <file>     :  Custom instrumentation configuration file \n' \
        '' \
        'See documentation for details \n'


def main():
    from prismo.constants import OPTION_LIST_SHORT, OPTION_LIST_LONG
    args = sys.argv[1:]
    optlist, target = getopt.getopt(args, OPTION_LIST_SHORT, OPTION_LIST_LONG)

    # option parsing
    help_quit = False

    # bootstrap environment and target loading
    if not help_quit:
        print 'Prismo PreAgent Initializing..'
        prepend_agent_into_pythonpath()
        try:
            print 'Bootstrapping Prismo .."' + ' '.join(args) + '"' + ' '.join(environ) \
                  + '"' + ' '.join(target) + '"'
            os.execvpe(target[0], args, environ)
        except OSError as exc:
            if exc.errno == errno.ENOENT:
                print '%s: no such file or directory' % target[0]
            elif exc.errno == errno.EPERM:
                print '%s: permission denied' % target[0]
            raise


def prepend_agent_into_pythonpath():
    import prismo.bootstrap
    pythonpath = [os.path.dirname(prismo.bootstrap.__file__)]
    from prismo.constants import PYTHONPATH, PYTHONUNBUFFERED
    if PYTHONPATH in environ:
        pythonpath.append(environ[PYTHONPATH])
    # print 'python path = ' + str(pythonpath)
    environ[PYTHONPATH] = ';'.join(pythonpath)
    print 'env:' + environ[PYTHONPATH]
    environ[PYTHONUNBUFFERED] = 'True'
