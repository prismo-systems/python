#!/usr/bin/env python
__copyright__ = """
* Copyright (c) 2018 Prismo Systems . All rights reserved.
"""

__author__ = 'Ramesh Mani'


class ServiceBase:
    def __init__(self):
        self.status = ServiceStatus.loaded

    def start(self, agent):
        # add trace log
        self.status = ServiceStatus.started

    def shutdown(self, agent):
        self.status = ServiceStatus.shutdown


class ServiceStatus:
    loaded = 0
    started = 1
    shutdown = 2

    def __init__(self):
        pass
