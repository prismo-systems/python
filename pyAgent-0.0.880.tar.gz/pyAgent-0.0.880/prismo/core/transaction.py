#!/usr/bin/env python
import os

__copyright__ = """
* Copyright (c) 2018 Prismo Systems . All rights reserved.
*
"""

__author__ = 'Ramesh Mani'

import threading
from prismo.util.pattern import Singleton
from prismo.core.message import MessageBodyElement, MessageElementType, MessageType, MessageEnvelope
from prismo.constants import PRINT_PREFIX_TRACE
import uuid
import thread
import json

SIGNATURE_ATTRIBUTE_TYPE = "__SIG_"
EVENT_PROPERTY_TYPE = "__EVT_"
METHOD_ENTRY_POINT = "__ENTRY__"


# Should implement __slots__ and getstate and setstate
# http://book.pythontips.com/en/latest/__slots__magic.html
# https://docs.python.org/2/library/pickle.html#object.__getstate__
class MethodContext(MessageBodyElement):
    # object_pool = []
    # max_instances = 15
    # should create a pool of objects per thread PrismoThreadLocalStack - and once the msg has been sent by the
    # msg delivery thread, mark the object as free and move to top of queue.

    __slots__ = ['id', 'sig_type', 'data', 'method_calls', 'caller']
    # set the agent once from the ProbeAdministrator, so that it is shared by all instances.
    pid = os.getpid()
    agent = None

    # def __new__(cls, *args, **kwargs):
    #     print 'MethodContext::new -' + len(cls.object_pool)
    #     instance = cls.object_pool.pop()
    #     if instance is None:
    #         instance = MessageBodyElement.__new__(cls, *args, **kwargs)
    #         # cls.object_pool.append(instance)
    #     return instance

    def __init__(self, element_id):
        super(MethodContext, self).__init__(MessageElementType.method_context)
        self.id = element_id
        self.signature_type = None
        self.args = None
        self.kwargs = None
        self.exception = None
        self.data = {}  # key values collected by the probes
        self.method_calls = []
        self.caller = None

    def __getstate__(self):
        return {'id': self.id,
                'sig_type': self.signature_type,
                'data': self.data,
                'method_calls': self.method_calls,
                'caller': self.caller}

    def __setstate__(self, state):
        self.id = state['id']
        self.signature_type = state['sig_type']
        self.args = None
        self.kwargs = None
        self.exception = None
        self.data = state['data']
        self.method_calls = state['method_calls']
        self.caller = state['caller']

    def __str__(self):
        return '{"id":"' + str(self.id) +\
                '","sig_type":"' + str(self.signature_type) +\
                '","data":' + json.dumps(self.data) +\
                ',"method_calls":' + repr(self.method_calls) + '}'

    def __repr__(self):
        return '{"id":"' + str(self.id) + \
               '","sig_type":"' + str(self.signature_type) + \
               '","data":' + json.dumps(self.data) +\
                ',"method_calls":' + repr(self.method_calls) + '}'

    def push_params(self, *args, **kwargs):
        self.args = args
        self.kwargs = kwargs

    def set_args(self, args_list):
        """
        Allow the args to be modified by probes before calling the target method.
        Used by the probe for Google pub/sub to instrument the callback passed by the subscriber
        :param args_list: a list of parameters to be passed.
        :return:
        """
        self.args = tuple(args_list)

    def set_kwargs(self, **kwargs_map):
        """
        Allow the args to be modified by probes before calling the target method.
        Used by the probe for Google pub/sub to instrument the callback passed by the subscriber
        :param kwargs_map: a list of parameters to be passed.
        :return:
        """
        self.kwargs = kwargs_map

    def set_data(self, k, v, is_signature_attribute=False):
        if is_signature_attribute:
            k = SIGNATURE_ATTRIBUTE_TYPE + k
        else:
            k = EVENT_PROPERTY_TYPE + k
        self.data[k] = v

    def get_data(self, k=None):
        if k:
            return self.data.get(k)
        else:
            return self.data

    def clear(self):
        self.data.clear()
        self.method_calls = None
        self.caller = None
        self.args = None
        self.kwargs = None
        self.exception = None
        self.id = None

    # can it throw stack overflow exception?
    def depth_first_clear(self):
        try:
            for method_context in reversed(self.method_calls):
                method_context.depth_first_clear()
        except Exception as e:
            print 'Exception ' + str(e)
        self.clear()

    def get_data_keys(self):
        return self.data.keys()

    # need to maintain call order
    def add_method_call(self, method_call):
        self.method_calls.append(method_call)
        method_call.caller = self

    def get_caller(self):
        return self.caller

    def is_root(self):
        if self.caller is None:
            return True
        return False

    def get_called_methods(self):
        return self.method_calls

    def get_signature_type(self):
        return self.signature_type

    def set_signature_type(self, sig_type):
        self.signature_type = sig_type

    def get_json(self):
        str_json = ' {'
        str_json += '\'method_call\':'
        str_json += self.id
        str_json += ','
        str_json += '\'method_data\':{'
        for key in self.get_data_keys():
            str_json += '\'' + str(key) + '\':\'' + self.get_data(key) + '\''
            str_json += ','
        str_json += '}'
        str_json += '\'method_calls\':['
        for calls in self.method_calls:
            str_json += calls.get_json()
            str_json += ','
        str_json += ']}'
        return str_json


class CustomEnc(json.JSONEncoder):

    def default(self, o):
        if isinstance(o, ExternalDecoratorContext):
            return {'__{}__'.format(o.__class__.__name__): o.__dict__}


# Should implement __slots__ and getstate and setstate
# http://book.pythontips.com/en/latest/__slots__magic.html
# https://docs.python.org/2/library/pickle.html#object.__getstate__
class TransactionContext(MessageBodyElement):
    __slots__ = ['root', 'correlation_id', 'caller_txn_id', 'caller_exit_point_id', 'sequence', 'entry_point_type', 'data',
                 'method_call_count', 'txn_id', 'thread_id', 'external_correlation_decorator']

    def __init__(self, transaction_administrator):
        super(TransactionContext, self).__init__(MessageElementType.transaction_context)
        self.root = None
        self.correlation_id = None
        self.caller_txn_id = None
        self.caller_exit_point_id = None
        self.sequence = 0
        self.calling_sequence = 0
        self.entry_point_type = 'Default'
        self.data = {}  # key values collected by the probes
        self.method_call_count = 0
        self.txn_id = uuid.uuid4().hex  # txn_id  for this tx. Corr_id stitches multiple txn(s)
        self.thread_id = thread.get_ident()
        self.cursor = None  # current position in the transaction
        self._transaction_administrator = transaction_administrator
        self.transaction_finished = False
        self.external_correlation_decorator = None
        # self.external_correlation_decorator = ExternalDecoratorContext()

    def __getstate__(self):
        return {'root': self.root,
                'correlation_id': self.correlation_id,
                'caller_txn_id': self.caller_txn_id,
                'caller_exit_point_id': self.caller_exit_point_id,
                'sequence': self.sequence,
                'entry_point_type': self.entry_point_type,
                'data': self.data,
                'method_call_count': self.method_call_count,
                'txn_id': self.txn_id,
                'thread_id': self.thread_id,
                'external_correlation_decorator': self.external_correlation_decorator}

    def __str__(self):
        if self.external_correlation_decorator and self.external_correlation_decorator.is_embedded:
            return '"txn_context": {"txn_id":"' + str(self.txn_id) +\
                    '","correlation_id":"' + str(self.correlation_id) +\
                    '","caller_txn_id":"' + str(self.caller_txn_id) +\
                    '","caller_exit_point_id":"' + str(self.caller_exit_point_id) +\
                    '","sequence":' + str(self.sequence) +\
                    ',"entry_point_type":"' + str(self.entry_point_type) +\
                    '","method_call_count":' + str(self.method_call_count) +\
                    ',"thread_id":"' + str(self.thread_id) +\
                    '","root":' + repr(self.root) +\
                    ',"data":' + json.dumps(self.data, cls=CustomEnc) +\
                    ',' + repr(self.external_correlation_decorator) + '}'
        else:
            return '"txn_context": {"txn_id":"' + str(self.txn_id) +\
                    '","correlation_id":"' + str(self.correlation_id) +\
                    '","caller_txn_id":"' + str(self.caller_txn_id) +\
                    '","caller_exit_point_id":"' + str(self.caller_exit_point_id) +\
                    '","sequence":' + str(self.sequence) +\
                    ',"entry_point_type":"' + str(self.entry_point_type) +\
                    '","method_call_count":' + str(self.method_call_count) +\
                    ',"thread_id":"' + str(self.thread_id) +\
                    '","root":' + repr(self.root) +\
                    ',"data":' + json.dumps(self.data, cls=CustomEnc) +\
                    '}'

    def __repr__(self):
        if self.external_correlation_decorator and self.external_correlation_decorator.is_embedded:
            return '"txn_context": {"txn_id":"' + str(self.txn_id) +\
                    '","correlation_id":"' + str(self.correlation_id) +\
                    '","caller_txn_id":"' + str(self.caller_txn_id) +\
                    '","caller_exit_point_id":"' + str(self.caller_exit_point_id) +\
                    '","sequence":' + str(self.sequence) +\
                    ',"entry_point_type":"' + str(self.entry_point_type) +\
                    '","method_call_count":' + str(self.method_call_count) +\
                    ',"thread_id":"' + str(self.thread_id) +\
                    '","root":' + repr(self.root) +\
                    ',"data":' + json.dumps(self.data, cls=CustomEnc) + \
                   ',' + repr(self.external_correlation_decorator) + '}'
        else:
            return '"txn_context": {"txn_id":"' + str(self.txn_id) +\
                    '","correlation_id":"' + str(self.correlation_id) +\
                    '","caller_txn_id":"' + str(self.caller_txn_id) +\
                    '","caller_exit_point_id":"' + str(self.caller_exit_point_id) +\
                    '","sequence":' + str(self.sequence) +\
                    ',"entry_point_type":"' + str(self.entry_point_type) +\
                    '","method_call_count":' + str(self.method_call_count) +\
                    ',"thread_id":"' + str(self.thread_id) +\
                    '","root":' + repr(self.root) +\
                    ',"data":' + json.dumps(self.data, cls=CustomEnc) + \
                    '}'

    def __setstate__(self, state):
        self.root = state['root']
        self.correlation_id = state['correlation_id']
        self.caller_txn_id = state['caller_txn_id']
        self.caller_exit_point_id = state['caller_exit_point_id']
        self.sequence = state['sequence']
        self.calling_sequence = 0
        self.entry_point_type = state['entry_point_type']
        self.data = state['data']
        self.method_call_count = state['method_call_count']
        self.txn_id = state['txn_id']
        self.thread_id = state['thread_id']
        self.cursor = None  # current position in the transaction
        self._transaction_administrator = None
        self.transaction_finished = False
        self.external_correlation_decorator = state['external_correlation_decorator']

    def tear_down(self):
        self.root.depth_first_clear()
        self.correlation_id = None
        self.caller_txn_id = None
        self.caller_exit_point_id = None
        self.sequence = 0
        self.calling_sequence = 0
        self.entry_point_type = 'Default'
        self.thread_id = None
        self.txn_id = None
        self.cursor = None
        self.root = None
        self.method_call_count = 0
        self.transaction_finished = False
        self.external_correlation_decorator = None

    def set_correlation_id(self, correlation_id):
        self.correlation_id = correlation_id

    def get_correlation_id(self):
        if self.correlation_id is None:
            self.correlation_id = uuid.uuid4().hex
        return self.correlation_id

    def set_caller_txn_id(self, txn_id):
        self.caller_txn_id = txn_id

    def set_caller_exit_point_id(self, txn_id):
        self.caller_exit_point_id = txn_id

    def get_caller_txn_id(self):
        return self.caller_txn_id

    def get_caller_exit_point_id(self):
        return self.caller_exit_point_id

    def set_sequence(self, sequence):
        self.sequence = sequence

    def get_sequence(self):
        return self.sequence

    def set_entry_point_type(self, entry_point_type):
        self.entry_point_type = entry_point_type

    def get_entry_point_type(self):
        return self.entry_point_type

    def get_txn_id(self):
        return self.txn_id

    def get_next_calling_sequence(self):
        self.calling_sequence += 1
        return self.calling_sequence

    def set_data(self, k, v, is_signature_attribute=False):
        if is_signature_attribute:
            k = SIGNATURE_ATTRIBUTE_TYPE + k
        else:
            k = EVENT_PROPERTY_TYPE + k
        self.data[k] = v

    def get_data(self, k=None):
        if k:
            return self.data.get(k)
        else:
            return self.data

    def has_external_correlation(self):
        return self.external_correlation_decorator is not None

    def set_external_correlation_decorator(self, ext_corr):
        self.external_correlation_decorator = ext_corr

    def get_external_correlation_decorator(self):
        return self.external_correlation_decorator

    # push works like a regular stack in the sense that it pushes and element into the stack
    # unlike pop, which moves the cursor back to the parent.
    def push(self, method_call):
        self.method_call_count += 1
        if self.cursor:
            self.cursor.add_method_call(method_call)
            self.cursor = method_call
        else:  # 1st method call in the stack, so transaction starting
            self.cursor = method_call
            self.root = method_call
            self._transaction_administrator.fire_transaction_started(self)

    # pop does not remove the current element from the stack. Instead it moves the
    # current cursor back to the caller (parent element)
    def pop(self):
        method_call = self.cursor
        if method_call.get_caller() is None:
            # transaction ended
            self.transaction_finished = True
            if self.external_correlation_decorator is None or self.external_correlation_decorator.is_embedded:
                self._transaction_administrator.fire_transaction_finished(self)
            else:
                self._transaction_administrator.fire_external_correlation_ready(self)
        else:
            self.cursor = method_call.get_caller()
        return method_call

    def peek(self):
        return self.cursor

    def size(self):
        return self.method_call_count

    def has_transaction_finished(self):
        return self.transaction_finished

    def get_json(self):
        str_json = ' {'
        str_json += '\'corr_id\':'
        str_json += str(self.get_correlation_id())
        str_json += ','
        str_json += str(self.get_caller_txn_id())
        str_json += ','
        str_json += str(self.get_sequence())
        str_json += ','
        str_json += '\'txn_id\':' + str(self.txn_id)
        str_json += ','
        str_json += '\'root\':' + self.root.get_json()
        str_json += '}'
        return str_json


class PrismoThreadLocalStack(Singleton):

    # This class maintains a thread local storage to record the transaction call path.
    # The class itself is a singleton therefore does not store anything else
    thread_local = threading.local()
    _transaction_administrator = None

    def __init__(self):
        self.thread_local = PrismoThreadLocalStack.thread_local

    # It is meant to be called at the end of every transaction so that the thread is ready of the next transaction
    #
    def init(self):
        if not hasattr(self.thread_local, 'needs_init'):
            self.thread_local.needs_init = False
            self.thread_local.transaction_context = TransactionContext(self._transaction_administrator)
            self.thread_local.should_skip = False

    def tear_down(self):
        self.thread_local.transaction_context = TransactionContext(self._transaction_administrator)

    @classmethod
    def set_transaction_administrator(cls, transaction_admin):
        cls._transaction_administrator = transaction_admin

    def set_correlation_id(self, correlation_id):
        self.thread_local.transaction_context.set_correlation_id(correlation_id)

    def get_correlation_id(self):
        return self.thread_local.transaction_context.get_correlation_id()

    def set_caller_txn_id(self, caller_txn_id):
        self.thread_local.transaction_context.set_caller_txn_id(caller_txn_id)

    def get_caller_txn_id(self):
        return self.thread_local.transaction_context.get_caller_txn_id()

    def set_caller_exit_point_id(self, caller_exit_point_id):
        self.thread_local.transaction_context.set_caller_exit_point_id(caller_exit_point_id)

    def get_caller_exit_point_id(self):
        return self.thread_local.transaction_context.get_caller_exit_point_id()

    def set_sequence(self, sequence):
        self.thread_local.transaction_context.set_sequence(sequence)

    def set_entry_point_type(self, entry_point_type):
        self.thread_local.transaction_context.set_entry_point_type(entry_point_type)

    def get_entry_point_type(self):
        return self.thread_local.transaction_context.get_entry_point_type()

    def get_next_calling_sequence(self):
        return self.thread_local.transaction_context.get_next_calling_sequence()

    def get_txn_id(self):
        return self.thread_local.transaction_context.get_txn_id()

    # should use these instead of the specific ones (corr_id and txn_id)
    def set_data(self, k, v, is_signature_attribute=False):
        self.thread_local.transaction_context.set_data(k, v, is_signature_attribute)

    def get_data(self, k):
        return self.thread_local.transaction_context.get_data(k)

    # push works like a regular stack in the sense that it pushes and element into the stack
    # unlike pop, which moves the cursor back to the parent.
    def push(self, method_call):
        self.thread_local.transaction_context.push(method_call)

    # pop does not remove the current element from the stack. Instead it moves the
    # current cursor back to the caller (parent element)
    def pop(self):
        method_call = self.thread_local.transaction_context.pop()
        if self.thread_local.transaction_context.has_transaction_finished():
            self.tear_down()
        return method_call

    def peek(self):
        return self.thread_local.transaction_context.peek()

    def size(self):
        return self.thread_local.transaction_context.size()

    def should_skip(self):
        return self.thread_local.should_skip

    def set_should_skip(self, flag):
        self.thread_local.should_skip = flag

    def set_external_correlation_decorator(self, ext_corr):
        self.thread_local.transaction_context.set_external_correlation_decorator(ext_corr)

    def get_external_correlation_decorator(self):
        return self.thread_local.transaction_context.get_external_correlation_decorator()


class TransactionAdministrator (Singleton):
    def __init__(self, agent):
        self.agent = agent
        self.logger = agent.get_logger(__name__)
        self.transaction_start_listeners = []
        self.transaction_finish_listeners = []
        self.external_correlation_listeners = []
        PrismoThreadLocalStack.set_transaction_administrator(self)

    def register_start_listener(self, listener):
        self.transaction_start_listeners.append(listener)

    def register_finish_listener(self, listener):
        self.transaction_finish_listeners.append(listener)

    def register_external_correlation_listener(self, listener):
        self.external_correlation_listeners.append(listener)

    def fire_transaction_started(self, transaction_context):
        for listener in self.transaction_start_listeners:
            try:
                listener.fire(transaction_context)
            except Exception as e:
                if self.logger.isEnabledForTrace():
                    self.logger.trace('Exception  firing event listener -' + str(e));

    def fire_transaction_finished(self, transaction_context):
        for listener in self.transaction_finish_listeners:
            try:
                # print 'Transaction finished event'
                listener.fire(transaction_context)
            except Exception as e:
                if self.logger.isEnabledForTrace():
                    self.logger.trace('Exception  firing event listener -' + str(e))

    def fire_external_correlation_ready(self, transaction_context):
        for listener in self.external_correlation_listeners:
            try:
                # print 'External Correlation ready event'
                listener.fire(transaction_context)
            except Exception as e:
                if self.logger.isEnabledForTrace():
                    self.logger.trace('Exception  firing event listener -' + str(e))


class EventListenerBase(object):
    def __init__(self, listener_id):
        self.id = listener_id

    def fire(self, transaction_context):
        pass


class TransactionStartEventListener(EventListenerBase):
    def __init__(self, listener_id, agent):
        super(TransactionStartEventListener, self).__init__(listener_id)
        self.id = listener_id
        self.agent = agent
        self.data_queue = agent.get_server_administrator().get_data_queue()

    def fire(self, transaction_context):
        # currently we don't anything
        pass


class TransactionFinishEventListener(EventListenerBase):
    def __init__(self, listener_id, agent):
        super(TransactionFinishEventListener, self).__init__(listener_id)
        self.id = listener_id
        self.agent = agent
        self.server_administrator = agent.get_server_administrator()

    def fire(self, transaction_context):
        # processes this in another thread by adding transaction_context to a queue.
        # TODO we need a TransactionContext pool else we will create too many objects
        # TODO same with MethodContext, but event listener is probably not the place for it
        # TODO maybe a msg queue 'sent' event which handles this
        # json_str = transaction_context.get_json()
        # print json.dumps(json_str)
        # msg = self.create_transaction_message(json_str)
        self.server_administrator.send_message(MessageType.transaction, transaction_context)

    @classmethod
    def create_transaction_message(cls, json_str):
        return 'MessageType: transaction{' + json_str + '}'


class ExternalCorrelationEventListener(EventListenerBase):
    def __init__(self, listener_id, agent):
        super(ExternalCorrelationEventListener, self).__init__(listener_id)
        self.id = listener_id
        self.agent = agent
        self.server_administrator = agent.get_server_administrator()

    def fire(self, transaction_context):
        # processes this in another thread by adding transaction_context to a queue.
        # TODO we need a TransactionContext pool else we will create too many objects
        # TODO same with MethodContext, but event listener is probably not the place for it
        # TODO maybe a msg queue 'sent' event which handles this
        # json_str = transaction_context.get_json()
        # print json.dumps(json_str)
        # msg = self.create_transaction_message(json_str)
        ext_corr = transaction_context.get_external_correlation_decorator()
        self.server_administrator.send_message(MessageType.external_correlation, ext_corr)


class ExternalDecoratorContext(MessageBodyElement):
    """
    This is a container to store data till it is ready to be sent to the collector.

    """
    __slots__ = ['correlation_id', 'entity_id', 'caller_txn_id', 'sequence', 'data',
                 'txn_id', 'correlation_keys', 'is_embedded']

    def __init__(self):
        super(ExternalDecoratorContext, self).__init__(MessageElementType.external_decoration)
        self.is_embedded = True
        self.correlation_id = None
        self.entity_id = "External Entity"
        self.caller_txn_id = None
        self.sequence = 0
        self.caller_exit_point_id = None  # is always the ID from agent if any
        self.calling_sequence = 0
        self.entry_point_type = 'Default'
        # Must contain the __EVT_node_type key with values 0 = Entry, 1 = Exit
        self.data = {}  # key - value collected by the probes
        self.txn_id = None    # txn_id  source transaction
        self.transaction_finished = False
        # key names - These are specific to the type of external correlation;
        # The values are in the data map and are used to generate the UUID
        self.correlation_keys = []

    def __getstate__(self):
        return {'correlation_id': self.correlation_id,
                'entity_id': self.entity_id,
                'caller_txn_id': self.caller_txn_id,
                'caller_exit_point_id': self.caller_exit_point_id,
                'sequence': self.sequence,
                'entry_point_type': self.entry_point_type,
                'data': self.data,
                'txn_id': self.txn_id,
                'correlation_keys': self.correlation_keys,
                'is_embedded': self.is_embedded}

    def __str__(self):
        return '"ext_txn_context": {"txn_id":"' + str(self.txn_id) +\
                '","correlation_id":"' + str(self.correlation_id) +\
                '","entity_id":"' + str(self.entity_id) + \
                '","caller_txn_id":"' + str(self.caller_txn_id) + \
                '","caller_exit_point_id":"' + str(self.caller_exit_point_id) +\
                '","sequence":' + str(self.sequence) + \
                ',"entry_point_type":"' + str(self.entry_point_type) +\
                '","correlation_keys":' + json.dumps(self.correlation_keys) + \
                ',"data":' + json.dumps(self.data) + '}'

    def __repr__(self):
        return '"ext_txn_context": {"txn_id":"' + str(self.txn_id) +\
                '","correlation_id":"' + str(self.correlation_id) +\
                '","entity_id":"' + str(self.entity_id) +\
                '","caller_txn_id":"' + str(self.caller_txn_id) +\
                '","caller_exit_point_id":"' + str(self.caller_exit_point_id) +\
                '","sequence":' + str(self.sequence) +\
                ',"entry_point_type":"' + str(self.entry_point_type) +\
                '","correlation_keys":' + json.dumps(self.correlation_keys) + \
                ',"data":' + json.dumps(self.data) + '}'

    def __setstate__(self, state):
        self.correlation_id = state['correlation_id']
        self.entity_id = state['entity_id']
        self.caller_txn_id = state['caller_txn_id']
        self.caller_exit_point_id = state['caller_exit_point_id']
        self.sequence = state['sequence']
        self.entry_point_type = state['entry_point_type']
        self.calling_sequence = 0
        self.data = state['data']
        self.txn_id = state['txn_id']
        self.correlation_keys = state['correlation_keys']
        self._transaction_administrator = None
        self.transaction_finished = False
        self.is_embedded = state['is_embedded']

    def tear_down(self):
        self.correlation_id = None
        self.entity_id = None
        self.caller_txn_id = None
        self.caller_exit_point_id = None
        self.sequence = 0
        self.entry_point_type = 'Default'
        self.calling_sequence = 0
        self.txn_id = None
        self.data = {}
        self.transaction_finished = False
        self.correlation_keys = []

    def set_correlation_id(self, correlation_id):
        self.correlation_id = correlation_id

    def get_correlation_id(self):
        if self.correlation_id is None:
            self.correlation_id = uuid.uuid4().hex
        return self.correlation_id

    def set_entity_id(self, ent_id):
        self.entity_id = ent_id

    def get_entity_id(self):
        return self.entity_id

    def add_correlation_key(self, correlation_key):
        self.correlation_keys.append(correlation_key)

    def get_correlation_keys(self):
        return self.correlation_keys

    def set_caller_txn_id(self, txn_id):
        self.caller_txn_id = txn_id

    def get_caller_txn_id(self):
        return self.caller_txn_id

    def set_caller_exit_point_id(self, txn_id):
        self.caller_exit_point_id = txn_id

    def get_caller_exit_point_id(self):
        return self.caller_exit_point_id

    def set_sequence(self, sequence):
        self.sequence = sequence

    def get_sequence(self):
        return self.sequence

    def set_entry_point_type(self, entry_point_type):
        self.entry_point_type = entry_point_type

    def get_entry_point_type(self):
        return self.entry_point_type

    def get_txn_id(self):
        return self.txn_id

    def set_txn_id(self, txn_id):
        self.txn_id = txn_id

    def set_data(self, k, v, is_signature_attribute=False):
        if is_signature_attribute:
            k = SIGNATURE_ATTRIBUTE_TYPE + k
        else:
            k = EVENT_PROPERTY_TYPE + k
        self.data[k] = v

    def get_data(self, k=None):
        if k:
            return self.data.get(k)
        else:
            return self.data

    def has_transaction_finished(self):
        return self.transaction_finished

    def get_json(self):
        str_json = ' {'
        str_json += '\'corr_id\':'
        str_json += str(self.get_correlation_id())
        str_json += ','
        str_json += str(self.get_caller_txn_id())
        str_json += ','
        str_json += str(self.get_sequence())
        str_json += ','
        str_json += '\'txn_id\':' + str(self.txn_id)
        str_json += '}'
        return str_json


#
# not used right now
# Will be used later for recording locally to find anomaly
class PrismoTransactionTree(Singleton):

    # Is a single Tree that holds all the unique transaction
    # paths in the application as seen by the agent. Its a tree of PrismoTransactionElement
    root = {}

    def __init__(self):
        self.root = PrismoTransactionTree.root

    # called by Singleton
    def init(self):
        pass

    def push_tx_element(self, parent, element):
        if parent is None:
            self.root[element.get_id()] = element
        else:
            parent.push_element(element)


class PrismoTransactionElement:
    def __init__(self, element_id, value):
        self.id = element_id
        self.value = value
        self.methods_called = {}

    def get_element_id(self):
        return self.id

    def get_value(self):
        return self.value

    def push_element(self, element):
        if self.methods_called.get(element.get_id()) is None:
            self.methods_called[element.get_id()] = element.get_value()
        return self.methods_called[element.get_id()]
