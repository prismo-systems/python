#!/usr/bin/env python

__copyright__ = """
* Copyright (c) 2018 Prismo Systems . All rights reserved.
*
"""

__author__ = 'Ramesh Mani'

import socket
# import psutil
import time
import uuid
import struct
from prismo.util.prismothreading import ThreadBase
import prismo.core.server as server
# try:
#     import cPickle as pickle
# except:
#     import pickle

# from prismo.metafile.protobuf.amon_msg_type_pb2 import app_agent_data, AMON_MSG_TYPE_APP_AGENT_DATA_RSP


# class ClientSocketConnection:
#     use_protobuf = False
#
#     def __init__(self, agent, connection_properties):
#         self.agent = agent
#         self.connection_properties = connection_properties
#         self._connection = None
#         self._status = server.ConnectionStatus.DISCONNECTED
#         self.logger = self.agent.get_logger(__name__)
#
#     # host on compute engine 10.138.0.2
#     def connect(self):
#         host = '127.0.0.1'
#         port = 50007
#         try:
#             self._status = server.ConnectionStatus.CONNECTING
#             self._connection = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
#             host = self.connection_properties['host']
#             port = int(self.connection_properties['data_port'])
#             self._connection.connect((host, port))
#             self._connection.send('__#PRISMO_AGENT#__')
#             self.logger.info('Successfully connected to ' + self.connection_properties['host'] + ' port:' + str(port))
#             self._status = server.ConnectionStatus.CONNECTED
#             return True
#         except Exception as e:
#             self.logger.error('Failed to connect to :' + host + ' port:' + str(port))
#             self.logger.error(str(e))
#             self._status = server.ConnectionStatus.ERROR
#             return False
#
#     def disconnect(self):
#         try:
#             self._connection.close()
#             self._status = server.ConnectionStatus.DISCONNECTED
#         except Exception as e:
#             self.logger.error('Failed to close connection. ' + str(e))
#             self._status = server.ConnectionStatus.ERROR
#
#     def send(self, msg_envelopes):
#         try:
#             if self._status == server.ConnectionStatus.CONNECTED:
#                 for env in msg_envelopes:
#                     if ClientSocketConnection.use_protobuf:  # this is protobuf over tcp
#                         message_internal = repr(env)
#                         # print message_internal
#                         agent_msg = app_agent_data()
#                         agent_msg.message_type = AMON_MSG_TYPE_APP_AGENT_DATA_RSP
#                         agent_msg.msg_id = 100
#                         agent_msg.agent_id = 100
#                         agent_msg.app_msg = message_internal
#                         message_serialized = agent_msg.SerializeToString()
#                         message_serialized += '__#PRISMO_PROTOBUF_END#__'
#                         self._connection.sendall(message_serialized)
#                     else:  # this is pickle over tcp
#                         message_serialized = pickle.dumps(env, pickle.HIGHEST_PROTOCOL)  # using string.could use binary
#                         message_serialized += '__#PRISMO_MESSAGE_END#__'
#                         self._connection.sendall(message_serialized)
#             else:
#                 self.logger.error('Failed to send message to server as connection status is ' + str(self._status))
#         except Exception as e:
#             self._status = server.ConnectionStatus.ERROR
#             self.logger.error('Exception while sending  message to server:' + str(e))
#             raise e
#
#     def send_keep_alive(self):
#         try:
#             if self._status == server.ConnectionStatus.CONNECTED:
#                 message_serialized = '__#PRISMO_KEEP_ALIVE#__'
#                 self._connection.sendall(message_serialized)
#             else:
#                 self.logger.error('Failed to send message to server as connection status is ' + str(self._status))
#         except Exception as e:
#             self._status = server.ConnectionStatus.ERROR
#             self.logger.error('Exception while sending  message to server:' + str(e))
#             raise e
#
#     def receive(self):
#         if self._status == server.ConnectionStatus.CONNECTED:
#             data = ''  # self._connection.recv(1024)
#             self.logger.debug('Server Response', repr(data))
#             return repr(data)
#
#
# # Todo
# class SSLClientSocketConnection:
#     def __init__(self):
#         pass
#

#######################################################################################################################

PROCMON_TYPE_ERROR = 0xf001
PROCMON_TYPE_SYSINFO = 0x0001
PROCMON_TYPE_PROCESS      =      0x0002
PROCMON_TYPE_FD           =      0x0003
PROCMON_TYPE_PF         =        0x0004          # aes
PROCMON_TYPE_PROC_ATTR    =      0x0005
PROCMON_TYPE_IFADDR       =      0x0006
PROCMON_TYPE_FD2         =       0x0007
PROCMON_TYPE_SYSCALL      =      0x0008
PROCMON_TYPE_DRVINFO      =      0x0009
PROCMON_TYPE_SWMON        =      0x000a
PROCMON_TYPE_SWMON2        =     0x000b
PROCMON_TYPE_FD3           =     0x000c
PROCMON_TYPE_CONN         =      0x000d
CTRL_TYPE_CONTEXT       =        0x0003
CTRL_TYPE_HEARTBEAT     =        0x0004
PROCMON_TYPE_APP_DATA   =        0x0104

AGENT_TYPE_PROCMON = 1
AGENT_TYPE_AES = 2
AGENT_TYPE_WINMON = 3

# print 'going into struct'
pm_tlv_struct = struct.Struct("!HH")
pm_sysinfo_struct = struct.Struct("!32s I H H q")
pm_context_struct = struct.Struct("!128s 32s 16s 16s 80s 32s 32s 32s 1s I")

# print 'Came out!'
pm_ifaddr_fix_struct = struct.Struct("!32sL")
pm_ifaddr_elm_struct = struct.Struct("!64s16s")
# print 'here'

# ctx = {"AGENT_NAME": "App Agent",
#        "HOSTNAME": "localhost",
#        "HOST_IP": "127.0.0.1",
#        "PLATFORM": "PYTHON",
#        "OS": "WINDOWS",
#        "BUILD_VERSION": 10,
#        "BUILD_PACKAGE": "App",
#        "BUILD_TIME": time.gmtime()}


class CollectorChannel(object):
    Control = 0
    Data = 1

    def __init__(self):
        pass


class CollectorAddress(object):
    def __init__(self, agent_registration, c):
        # print 'Getting agent registration'
        if c == CollectorChannel.Control:
            self.port = agent_registration.port
        elif c == CollectorChannel.Data:
            self.port = agent_registration.procmon_port
        else:
            raise Exception('CollectorChannel Type unknown')
        self.address = agent_registration.host
        self.channel = c
        # print 'done Getting agent registration'


# void
# CollectorSocket::startThread()
# {
#     keep_working = true;
# worker_thread = std::make_shared < std::thread > (& CollectorSocket::maintainSocket, this);
# }
#
# void
# CollectorSocket::shutdownThread()
# {
#     keep_working = false;
# worker_thread->join();
# worker_thread = nullptr;
# }
class ControlConnectionThread(ThreadBase):
    def __init__(self, agent, collector_connection):
        super(ControlConnectionThread, self).__init__(name='control_connection', target=self.maintain_connection, kwargs={'control_thread': self})
        self.agent = agent
        self.conn = collector_connection
        self.setDaemon(True)
        self.logger = agent.get_logger(__name__)

    def establish_connection(self):
        self.logger.info("ControlConnectionThread : establish_connection :")
        if self.conn.connect():
            try:
                self.conn.setup_socket()
                self.conn.seq = 0
                self.logger.info('Established control channel with collector..')
                return True
            except Exception as e1:
                self.logger.info('Failed to establish control channel with collector. ' + str(e1))
                return False
        else:
            self.logger.info('Failed to establish control channel with collector..')
            return False

    def maintain_connection(self, control_thread=None):
        if control_thread:
            control_thread.maintain_connection_1()
        else:
            self.maintain_connection_1()

    def maintain_connection_1(self):
        success_count = 0
        while True:
            try:
                while self.conn.ready is False:
                    if self.establish_connection() is False:
                        time.sleep(5)
                self.conn.send_heart_beat()
                success_count += 1
                self.conn.seq += 1
                time.sleep(15)
            except Exception as e:
                self.log_failure(e, success_count)
                try:
                    self.conn.reset_state()
                    self.conn.close()
                    return False
                except Exception as ee:
                    self.logger.error("Failed to close disconnected control channel " + str(ee))
                    return False

    def log_failure(self, e, success_count):
        try:
            socket_err = 'Control channel failure -  ' + self.agent.get_agent_id() + "  :" + str(success_count)
            self.logger.warn(socket_err)
        except Exception as e:
            self.logger.error("Failure to log connection error" + str(e))


class CollectorSocket(object):
    conn_hostname = None

    def __init__(self, agent, address):
        self.agent = agent
        self.address = address
        self._status = server.ConnectionStatus.DISCONNECTED
        self.ready = False
        self.seq = 0
        self._connection = None
        self.pid = 100
        self.logger = agent.get_logger(__name__)

    def setup_socket(self):
        if self.address.channel == CollectorChannel.Control:
            self.send_context()
        else:
            self.send_sysinfo(PROCMON_TYPE_SYSINFO)
            self.send_ifaddr()
        self.ready = True

    def send_heart_beat(self):
        if self.address.channel == CollectorChannel.Control:
            self.send_sysinfo(CTRL_TYPE_HEARTBEAT)
        else:
            self.send_sysinfo(PROCMON_TYPE_SYSINFO)

    def reset_state(self):
        # print "socket " + self.address.address + ":" + str(self.address.port) + " state reset"
        self._status = server.ConnectionStatus.DISCONNECTED
        self.ready = False

    def send_keep_alive(self):
        self.send_heart_beat()

    def close(self):
        self._connection.close()

# void
# CollectorSocket::maintainSocket()
# {
#
#     cout << "socket maintain thread started for: " << addr.port << endl;
# while (keep_working) {
# try {
# if (!ready) {
# connect();
# cout << "connected to " << addr.port << endl;
# setupSocket();
# cout << "ready " << addr.port << endl;
# seq = 0;
# }
# while (keep_working) {
# sendHeartBeat();
# seq++;
# std::
#     this_thread::sleep_for(std::chrono::milliseconds(1000));
# }
# }
# catch(const
# CollectorSocketException &) {
# resetState();
# }
# }
#
# }
    def ip4_ifaddresses(self):
        """
        This function will return all IPv4 interface and their addresses in dictionary format.

        Sample psutil.net_if_addrs() would be like:
            {'Ethernet 4':
                [snic(family=-1, address='52-54-00-7F-54-CC', netmask=None, broadcast=None, ptp=None),
                 snic(family=2, address='169.254.218.5', netmask=None, broadcast=None, ptp=None),
                 snic(family=23, address='fe80::588e:de0c:5375:da05', netmask=None, broadcast=None, ptp=None)],

             'Ethernet':
                [snic(family=-1, address='52-54-00-BD-A7-71', netmask=None, broadcast=None, ptp=None),
                 snic(family=2, address='10.0.3.213', netmask=None, broadcast=None, ptp=None),
                 snic(family=23, address='fe80::a071:2891:40a2:bbac', netmask=None, broadcast=None, ptp=None)],

             'Loopback Pseudo-Interface 1':
                 [snic(family=2, address='127.0.0.1', netmask=None, broadcast=None, ptp=None),
                  snic(family=23, address='::1', netmask=None, broadcast=None, ptp=None)]}

        :return: Data return will be a dictionary like the following:
              {'Ethernet 4': ['169.254.218.5'],             # there could be more than one IP in the list
               'Ethernet': ['10.0.3.213'],
               'Loopback Pseudo-Interface 1':['127.0.0.1']}
        """
        # ifa_table = {}
        # for ifname, net_ifaddr_list in psutil.net_if_addrs().iteritems():
        #     ifaddrs = [net_ifaddr[1] for net_ifaddr in net_ifaddr_list
        #                if net_ifaddr[0] == socket.AF_INET]
        #     if ifaddrs:
        #         ifa_table[ifname] = ifaddrs
        # return ifa_table
        # hardcode to something as psutil is a 3rd party lib. We need to find an alternative
        agent_ip = self.agent.get_agent_ip().encode("ascii")
        return {'Ethernet 4': [agent_ip],   'Ethernet': [agent_ip],'Loopback Pseudo-Interface 1': ['127.0.0.1']}

    def get_ifaddr(self):
        ifa_table = self.ip4_ifaddresses()
        # print 'Got ifa_table' + str(ifa_table)
        num_addr = 0
        data_elm_packed_all = ''
        for intf, ip_list in ifa_table.iteritems():
            for ip in ip_list:
                data_elm = (intf, ip)
                data_elm_packed = pm_ifaddr_elm_struct.pack(*data_elm)
                data_elm_packed_all += data_elm_packed
                num_addr += 1

        data_fix = (self.conn_hostname, num_addr)
        data_fix_packed = pm_ifaddr_fix_struct.pack(*data_fix)
        data_packed = data_fix_packed + data_elm_packed_all
        # print 'Packed data :' + data_packed
        return data_packed

    def get_sysinfo(self):
        # Either socket.gethostname (short name like "ip-172-31-18-21") or
        # socket.getfqdn() (long name like "ip-172-31-18-21.us-west-1.compute.internal")
        # could be used to obtain the hostname.
        #
        # Though, it should be noted that host ip may not always be able to get from fqdn
        # by calling gethostbyname() in some case.  Some special handling should be applied.
        #     hostname = socket.getfqdn()
        #     try:
        #         host_ip = socket.gethostbyname(hostname)
        #     except socket.gaierror:
        #         hostname = socket.gethostname()
        #         host_ip = socket.gethostbyname(hostname)
        #     host_ip = socket.gethostbyname(hostname)
        #
        # As it's decided to use the interface IP (which could be different from host IP
        # when the host has multiple IPs) to identify the host, the choice for short or
        # long hostname should not be affected by how we get the host IP.
        if self.conn_hostname:
            hostname = self.conn_hostname
        else:
            hostname = socket.gethostname()
            # It's observed that, for a given host, say myhost.sj.prismosystems.com, the result depends on Linux version.
            #    Linux         socket.gethostname()         socket.getfqdn()
            #    -----------   --------------------         ----------------
            #    ubuntu 14.04  myhost                       myhost
            #    Centos 7.1    myhost.sj.prismosystems.com  myhost.sj.prismosystems.com
            #    Centos 6.6    myhost                       myhost.sj.prismosystems.com
            #
            # To unify this, we will always return the base hostname without fqdn.
            hostname = hostname.split('.')[0]
            self.conn_hostname = hostname

        # Instead of getting the host IP from socket.gethostbyname(hostname),
        # the IP address obtained from the actual socket connection is preferred
        # since a host may have many interface.
        # host_ip = sock.getsockname()[0]
        conn_type = AGENT_TYPE_AES
        agent_id = str(self.agent.get_agent_id())[:18]
        aes_sysinfo = {
            # "hostname": "{:32s}".format(hostname),
            "hostname": "{:32s}".format(agent_id),
            "sequence": "{:10d}".format(self.seq),
            "version": "{:5d}".format(1),
            "conn_type": "{:5d}".format(conn_type),
            "time_ms": time.time()
        }
        sys_data = (aes_sysinfo["hostname"],
                    int(aes_sysinfo["sequence"]),
                    int(aes_sysinfo["version"]),
                    int(aes_sysinfo["conn_type"]),
                    long(aes_sysinfo["time_ms"]))
        self.seq += 1
        # print "sys_data :" + str(sys_data)
        return sys_data

    def get_context_message(self):
        agent_id = str(self.agent.get_agent_id())[:18]
        agent_ip = self.agent.get_agent_ip()
        # print "agentID :" + agent_id
        # v = "{:128s}".format("App Agent " + agent_id + "_REPLACE_")
        # name  = v.replace("_REPLACE_", '\0')
        ctx = {"AGENT_NAME": "{:128s}".format(agent_id),
               "HOSTNAME": "{:32s}".format(agent_id),
               "HOST_IP": "{:16s}".format(agent_ip),
               "PLATFORM": "{:16s}".format("PYTHON"),
               "OS": "{:80s}".format("WIN x86_64 Windows Windows 10.0 Windows"),
               "BUILD_VERSION": "{:32s}".format("10"),
               "BUILD_PACKAGE": "{:32s}".format("App"),
               "BUILD_TIME": "{:32s}".format("10000000"),
               "NSCMD": "{:1s}".format("C"),
               "NSINTERVAL": "{:10d}".format(100000000)}
        data = (ctx["AGENT_NAME"],
                ctx["HOSTNAME"],
                ctx["HOST_IP"],
                ctx["PLATFORM"],
                ctx["OS"],
                ctx["BUILD_VERSION"],
                ctx["BUILD_PACKAGE"],
                ctx["BUILD_TIME"],
                ctx["NSCMD"],
                int(ctx["NSINTERVAL"]))
        self.logger.debug("ctx :" + str(data) + " Agent Name len:" + str(len(ctx["AGENT_NAME"])))
        # print "ctx :" + str(data) + " Agent Name len:" + str(len(ctx["AGENT_NAME"]))

        return data

    def connect(self):
        try:
            self.logger.info("Trying socket connection : " + str(self.address.address) + str(self.address.port))
            self._status = server.ConnectionStatus.CONNECTING
            self._connection = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            host = self.address.address
            port = int(self.address.port)
            # print 'Connecting to ' + host + ":" + str(port)
            self._connection.connect((host, port))
            # print 'Successfully connected to ' + self.address.address + ' port:' + str(self.address.port)
            self.logger.info('Successfully connected to ' + self.address.address + ' port:' + str(self.address.port))
            self._status = server.ConnectionStatus.CONNECTED
            return True
        except Exception as e:
            self.logger.error('Failed to connect to :' + self.address.address + ' port:' + str(self.address.port))
            # print 'Failed to connect to :' + self.address.address+ ' port:' + str(self.address.port)
            self.logger.error(str(e))
            self._status = server.ConnectionStatus.ERROR
            return False

    def get_header(self, m_type, length):
        """
        :param m_type: PROCMON_TYPE_SYSINFO
        :param length: length of the packed data being sent
        :param process_id:
        :return:
        """
        epoch_time = time.time()
        header_packer = struct.Struct('!8s Q I I I I I I I I')
        header = ('AAAABBBB', epoch_time, m_type, length, 0, 0, self.pid, 0, 0, 0)
        return header_packer.pack(*header)

    def send(self, message, check_ready=True):
        if not self.ready and check_ready:
            return
        self._connection.sendall(message)
        # print 'sent msg'

    def send_context(self):
        # print 'Sending Context for connection'
        context_data = self.get_context_message()
        packed_context_data = pm_context_struct.pack(*context_data)
        packed_header = self.get_header(CTRL_TYPE_CONTEXT, len(packed_context_data))
        # print 'Send Context: ' + str(self._connection.getsockname()) + " Peer:" + str(self._connection.getpeername())
        self.send(packed_header, False)
        self.send(packed_context_data, False)
        # print 'sent context ' + packed_header

    def send_sysinfo(self, m_type):
        sysinfo_data = self.get_sysinfo()
        packed_sysinfo_data = pm_sysinfo_struct.pack(*sysinfo_data)
        packed_header = self.get_header(m_type, len(packed_sysinfo_data))
        # print 'Send Sys: ' + str(self._connection.getsockname()) + " Peer:" + str(self._connection.getpeername())
        self.send(packed_header, False)
        self.send(packed_sysinfo_data, False)
        # print 'sent sysinfo'

    def send_ifaddr(self):
        ifaddr_data = self.get_ifaddr()   # this returns packed
        # print ' Got packed ifddr' + str(ifaddr_data)
        packed_header = self.get_header(PROCMON_TYPE_IFADDR, len(ifaddr_data))
        # print 'Send ifaddr: ' + str(self._connection.getsockname()) + " Peer:" + str(self._connection.getpeername())
        self.send(packed_header, False)
        self.send(ifaddr_data, False)
        # print 'Sent ifaddr'

    def send_data(self, msg_envelopes):
        try:
            if self._status == server.ConnectionStatus.CONNECTED:
                for env in msg_envelopes:
                    message_internal = repr(env)
                    # print message_internal
                    # agent_msg = app_agent_data()
                    # agent_msg.message_type = AMON_MSG_TYPE_APP_AGENT_DATA_RSP
                    # agent_msg.msg_id = 100
                    # agent_msg.agent_id = 100
                    # agent_msg.app_msg = message_internal
                    # message_serialized = agent_msg.SerializeToString()
                    # self._connection.sendall(message_serialized)
                    # packed_header = self.get_header(PROCMON_TYPE_APP_DATA, len(message_serialized))
                    # self.send(packed_header, False)
                    # self.send(message_serialized, False)
                    packed_header = self.get_header(PROCMON_TYPE_APP_DATA, len(message_internal))
                    # print 'Send data: ' + str(self._connection.getsockname()) + " Peer:" + str(
                    #    self._connection.getpeername())
                    self.send(packed_header, False)
                    self.send(message_internal, False)
            else:
                self.logger.error('Failed to send message to server as connection status is ' + str(self._status))
                # print 'Failed to send message to server as connection status is ' + str(self._status)
        except Exception as e:
            self._status = server.ConnectionStatus.ERROR
            self.logger.error('Exception while sending  message to server:' + str(e))
            raise e

