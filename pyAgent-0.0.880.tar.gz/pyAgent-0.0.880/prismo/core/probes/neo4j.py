#!/usr/bin/env python

__copyright__ = """
* Copyright (c) 2018 Prismo Systems . All rights reserved.
*
"""

__author__ = 'Ramesh Mani'

from prismo.core.probes import ProbeBase


class ConnectionRun(ProbeBase):
    """
    version 1.7
    class:`~neobolt.direct.Connection`
    method: `run`
    """
    def __init__(self, agent):
        ProbeBase.__init__(self, agent)
        self.agent = agent
        self.logger = agent.get_logger(__name__)

    def enter(self, instruction, context):
        if self.logger.isEnabledForTrace():
            self.logger.trace('ConnectionRun - enter')
        context.set_signature_type('Neo4J')
        parameters = None
        connection_obj = context.args[0]
        context.set_data('server', str(connection_obj.server), True)
        if len(context.args) > 1:
            context.set_data('statement_text', context.args[1], True)
        if len(context.args) > 2:
            parameters = context.args[2]
        elif context.kwargs.get('parameters'):
            parameters = context.kwargs.get('parameters')
        for k, v in parameters.items():
            context.set_data(k, v)

    def exit(self, instruction, context):
        if self.logger.isEnabledForTrace():
            self.logger.trace('ConnectionRun - exit')


class ConnectionBase(ProbeBase):
    """
    class:`~neobolt.direct.Connection`
    method: `fetch`
    method: `hello`
    method: `pull_all`
    method: `reset`
    method: `send`
    method: `sync`
    """
    def __init__(self, agent):
        ProbeBase.__init__(self, agent)
        self.agent = agent
        self.logger = agent.get_logger(__name__)

    def enter(self, instruction, context):
        if self.logger.isEnabledForTrace():
            self.logger.trace('ConnectionBase - enter')
        connection_obj = context.args[0]
        context.set_data('server', str(connection_obj.server), True)
        context.set_signature_type('Neo4J')

    def exit(self, instruction, context):
        if self.logger.isEnabledForTrace():
            self.logger.trace('ConnectionBase - exit')

