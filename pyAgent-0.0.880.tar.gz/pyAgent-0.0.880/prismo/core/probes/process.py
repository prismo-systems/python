#!/usr/bin/env python

__copyright__ = """
* Copyright (c) 2018 Prismo Systems . All rights reserved.
*
"""

__author__ = 'Ramesh Mani'

from prismo.core.probes import ProbeBase

##
#  This contains all the probes that track commands that
# start a new process outside the application process.
# examples are execute a shell script

#
# os.system("some_command with args")
# stream = os.Popen("some_command with args")
# subprocess.call("echo Hello World", shell=True)
# subprocess.check_call
# subprocess.check_output
# subprocess.Popen.__init__   should first monitor this
# subprocess.Popen._execute_child
# in _subprocess.py
# # def CreateProcess(app_name, cmd_line, proc_attrs, thread_attrs, inherit, flags, env_mapping,
# curdir, startup_info): # real signature unknown; restored from __doc__
# should flag loading the module itself if it happens

# most of these wil use eval and we should insert a probe for that


class SystemProbe(ProbeBase):
    skip_flag_count = 0

    def __init__(self, agent):
        ProbeBase.__init__(self, agent)
        self.agent = agent
        self.logger = agent.get_logger(__name__)

    def enter(self, instruction, context):
        if SystemProbe.skip_flag_count > 0:
            self.logger.trace('Skipped SystemProbe Enter')
            return
        if self.logger.isEnabledForTrace():
            self.logger.trace('SystemProbe - enter')
        context.set_data('CMD', context.args[0], True)
        # print "CMD :" + str(context.args[0])
        # import traceback
        # traceback.print_stack()
        context.set_signature_type('System Call')

    def exit(self, instruction, context):
        if SystemProbe.skip_flag_count > 0:
            self.logger.trace('Skipped SystemProbe Exit')
            return
        if self.logger.isEnabledForTrace():
            self.logger.trace('SystemProbe - exit')
        child_process = context.ret_val
        if child_process and child_process.pid:
            context.set_data('child_pid', str(child_process.pid))
            from prismo.core.transaction import PrismoThreadLocalStack
            tlc = PrismoThreadLocalStack()
            pids = tlc.get_data('child_process_ids')
            if pids is None:
                tlc.set_data('child_process_ids', str(child_process.pid))
            else:
                pids += ',' + str(child_process.pid)
                tlc.set_data('child_process_ids', pids)


class SystemProbeSkip(ProbeBase):
    #
    # Allows skipping system probe. Need to make this thread safe
    #
    def __init__(self, agent):
        ProbeBase.__init__(self, agent)
        self.agent = agent
        self.logger = agent.get_logger(__name__)

    def enter(self, instruction, context):
        if self.logger.isEnabledForTrace():
            self.logger.trace('SystemProbeSkip - enter')
        SystemProbe.skip_flag_count += 1

    def exit(self, instruction, context):
        if self.logger.isEnabledForTrace():
            self.logger.trace('SystemProbeSkip - exit')

        if SystemProbe.skip_flag_count > 0:
            SystemProbe.skip_flag_count -= 1

