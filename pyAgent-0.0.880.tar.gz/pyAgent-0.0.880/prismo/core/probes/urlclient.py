#!/usr/bin/env python

__copyright__ = """
* Copyright (c) 2018 Prismo Systems . All rights reserved.
*
"""

__author__ = 'Ramesh Mani'

from prismo.core.probes import ProbeBase

try:
    urllib2enabled = True
    import urllib2
except Exception as e:
    urllib2enabled = False


class Urllib2Urlopen(ProbeBase):
    """
        This probe instruments urllib2.urlopen to capture the outgoing URL.
    """
    def __init__(self, agent):
        ProbeBase.__init__(self, agent)
        self.agent = agent
        self.logger = agent.get_logger(__name__)
        if not urllib2enabled:
            self.urllib2enabled = False
        else:
            self.urllib2enabled = True

    def enter(self, instruction, context):
        # print "Urllib2Urlopen - enter : " + str(instruction)
        if self.logger.isEnabledForTrace():
            self.logger.trace('Urllib2Urlopen - enter')
        url = context.args[0]  # index 0 as its package method. (No instance) this could be a Request object.
        print 'Check instance type: ' + str(self.urllib2enabled)
        if self.urllib2enabled and isinstance(url,  urllib2.Request):
            url = url.get_full_url()
            print 'Check instance type 2 ' + str(url)

        context.set_signature_type("Client_Socket")
        context.set_data('URL', str(url), True)

    def exit(self, instruction, context):
        if self.logger.isEnabledForTrace():
            self.logger.trace('Urllib2Urlopen - exit')


class UrllibUrlopen(ProbeBase):
    """
        This probe instruments urllib.urlopen to capture the outgoing URL.
    """
    def __init__(self, agent):
        ProbeBase.__init__(self, agent)
        self.agent = agent
        self.logger = agent.get_logger(__name__)

    def enter(self, instruction, context):
        # print "Urllib2Urlopen - enter : " + str(instruction)
        if self.logger.isEnabledForTrace():
            self.logger.trace('Urllib.Urlopen - enter')
        url = context.args[0]  # index 0 as its package method. (No instance) this could be a Request object.
        context.set_signature_type("Client_Socket")
        context.set_data('URL', str(url), True)

    def exit(self, instruction, context):
        if self.logger.isEnabledForTrace():
            self.logger.trace('Urllib.Urlopen - exit')


class HttpConnection(ProbeBase):
    """
        This probe instruments HttpConnection.connect to capture the remote IP address.
        Should skip this for all calls except calls within Urllib2.Urlopen, Urllib.Urlopen
        The flag should be set by the Urllib2Urlopen.enter and reset in Urllib2Urlopen.exit (and others listed above)
    """
    def __init__(self, agent):
        ProbeBase.__init__(self, agent)
        self.agent = agent
        self.logger = agent.get_logger(__name__)

    def enter(self, instruction, context):
        # print 'HttpConnection - enter'
        if self.logger.isEnabledForTrace():
            self.logger.trace('HttpConnection - enter')

    def exit(self, instruction, context):
        if self.logger.isEnabledForTrace():
            self.logger.trace('HttpConnection - exit')
        thisObj = context.args[0]
        if thisObj.sock is not None:
            ipAddress = thisObj.sock.getpeername()[0]
            port = thisObj.sock.getpeername()[1]
            context.set_data('IpAddress', str(ipAddress), True)
            context.set_data('Port', str(port), True)
            self.logger.info('HttpConnection - exit: ' + str(ipAddress))
