#!/usr/bin/env python
import uuid

__copyright__ = """
* Copyright (c) 2018 Prismo Systems . All rights reserved.
*
"""

__author__ = 'Ramesh Mani'
from prismo.core.probes import ProbeBase
from prismo.core.transaction import PrismoThreadLocalStack, ExternalDecoratorContext
import uuid
import traceback
import sys
from prismo.api.constants import EXIT_POINT_ID, CALLER_EXIT_POINT_ID


class DataStoreIterator(ProbeBase):
    """
    class:`~google.cloud.datastore.query.Iterator`
    method:_`next_page`

    probes should decorate the following as well
     - Type : Entry/Exit/Middle
     - Sub Type : Servlet/Database/RestClient/etc .. as new probes are written to cover additional Entry/Exit points
     The Type will be used to lookup a list of keys for the type to form the signature.
     This lookup set is in the server and agent does not need to send it.
    """
    def __init__(self, agent):
        ProbeBase.__init__(self, agent)
        self.agent = agent
        self.logger = agent.get_logger(__name__)

    def enter(self, instruction, context):
        if self.logger.isEnabledForTrace():
            self.logger.trace('DataStoreIterator - enter')
        # the instrumented 'self' object  Iterator object
        iterator_obj = context.args[0]
        query_obj = iterator_obj._query # accessing private member but that's OK
        query_str = ''
        if query_obj.project is not None:
            query_str += 'project: ' + query_obj.project
        if query_obj.kind is not None:
            query_str += '; kind: ' + query_obj.kind
        else:
            query_str += '; kind: '
        if query_obj.ancestor is not None:
            query_str += '; ancestor: ' + query_obj.ancestor
        if query_obj.namespace is not None:
            query_str += '; namespace: ' + query_obj.namespace
        filter_str = '['
        if query_obj.filters is not None:
            for filter_tuple in query_obj.filters[:]:
                filter_str += filter_tuple[0] + filter_tuple[1] + ', '
            query_str += '; filters: ' + filter_str + ']'
        if query_obj.projection is not None:
            query_str += '; projection: ['
            for proj in query_obj.projection[:]:
                query_str += proj + ', '
            query_str += ']'
        context.set_data('query', query_str, True)  # should only get the names not the values
        # set transaction level properties data like this
        # thread_local_stack = PrismoThreadLocalStack()
        # thread_local_stack.set_data('URL', request_obj.url)
        context.set_signature_type('Google Datastore')

    def exit(self, instruction, context):
        if self.logger.isEnabledForTrace():
            self.logger.trace('DataStoreIterator - exit')


class DataStoreClientXXXMulti(ProbeBase):
    """
    class:`~google.cloud.datastore.client.Client`
    method:`get_multi` and delete_multi
    """
    def __init__(self, agent):
        ProbeBase.__init__(self, agent)
        self.agent = agent
        self.logger = agent.get_logger(__name__)

    def enter(self, instruction, context):
        if self.logger.isEnabledForTrace():
            self.logger.trace('DataStoreClientXXXMulti - enter')
        # the instrumented 'self' object  Iterator object
        # print 'args length:' + str(len(context.args))
        # print 'kwargs length:' + str(len(context.kwargs))
        client_obj = context.args[0]
        keys_list = context.kwargs['keys']
        query_str = ''
        if client_obj.project is not None:
            query_str += 'project: ' + client_obj.project
        if client_obj.namespace is not None:
            query_str += '; namespace: ' + client_obj.namespace
        # use private property '_path' since key.path property getter creates a deep copy. CPU, memory and latency!
        # We need a set of unique paths only. No IDs or names. path is a 2D array of kind + (ID or names)
        # Should use SortedSet but that is an external library and at this point not possible.
        # Once we can isolate libraries included by the agent (like a classloader in Java) its possible
        paths = set()
        for key in keys_list:           # get_multi can fetch multiple keys, so a list of keys
            path_str = ''
            for key_map in key._path:   # key._path is an array of key maps  [{'kind': 'Book', 'id': 5629499534213120L}]
                for k,v in key_map.items():
                    if k == 'id' or k == 'name':
                        path_str += k + ', '
                    else:
                        path_str += k + '=' + v + ', '
            paths.add(path_str)
        for combined_paths in paths:
            query_str += '; path: ' + str(combined_paths)
        context.set_data('keys', query_str, True)  # should only get the 'kind' not the names and IDs
        context.set_signature_type('Google Datastore')

    def exit(self, instruction, context):
        if self.logger.isEnabledForTrace():
            self.logger.trace('DataStoreClientXXXMulti - exit')


class DataStoreClientPutMulti(ProbeBase):
    """
    class:`~google.cloud.datastore.client.Client`
    method:`put_multi`
    """
    def __init__(self, agent):
        ProbeBase.__init__(self, agent)
        self.agent = agent
        self.logger = agent.get_logger(__name__)

    def enter(self, instruction, context):
        if self.logger.isEnabledForTrace():
            self.logger.trace('DataStoreClientPutMulti - enter')
        # the instrumented 'self' object  Iterator object
        # print 'args length:' + str(len(context.args))
        # print 'kwargs length:' + str(len(context.kwargs))
        client_obj = context.args[0]
        entities = context.kwargs['entities']
        keys_list = []
        for entity in entities:
            keys_list.append(entity.key)
        query_str = ''
        if client_obj.project is not None:
            query_str += 'project: ' + client_obj.project
        if client_obj.namespace is not None:
            query_str += '; namespace: ' + client_obj.namespace
        # use private property '_path' since key.path property getter creates a deep copy. CPU, memory and latency!
        # We need a set of unique paths only. No IDs or names. path is a 2D array of kind + (ID or names)
        # Should use SortedSet but that is an external library and at this point not possible.
        # Once we can isolate libraries included by the agent (like a classloader in Java) its possible
        paths = set()
        for key in keys_list:           # put_multi can update multiple entities, so a list of keys
            path_str = ''
            for key_map in key._path:   # key._path is an array of key maps  [{'kind': 'Book', 'id': 5629499534213120L}]
                for k,v in key_map.items():
                    if k == 'id' or k == 'name':
                        path_str += k + ', '
                    else:
                        path_str += k + '=' + v + ', '
            paths.add(path_str)
        for combined_paths in paths:
            query_str += '; path: ' + str(combined_paths)
        context.set_data('keys', query_str, True)  # should only get the 'kind' not the names and IDs
        context.set_signature_type('Google Datastore')

    def exit(self, instruction, context):
        if self.logger.isEnabledForTrace():
            self.logger.trace('DataStoreClientPutMulti - exit')


class StorageReloadBucket(ProbeBase):
    """
    class:`~google.cloud.storage.bucket`
    method:`reload`
    """
    def __init__(self, agent):
        ProbeBase.__init__(self, agent)
        self.agent = agent
        self.logger = agent.get_logger(__name__)

    def enter(self, instruction, context):
        if self.logger.isEnabledForTrace():
            self.logger.trace('StorageReloadBucket - enter')
        # the instrumented 'self' object  Iterator object
        # print 'args length:' + str(len(context.args))
        # print 'kwargs length:' + str(len(context.kwargs))
        bucket = context.args[0]
        if bucket.user_project is not None:
            context.set_data('user_project', bucket.user_project, True)
        if bucket.path is not None:
            context.set_data('path', bucket.path)
        context.set_signature_type('Google Cloud Storage')

    def exit(self, instruction, context):
        if self.logger.isEnabledForTrace():
            self.logger.trace('StorageReloadBucket - exit')


#  Google Cloud Storage probes
class StorageBlobUploadFile(ProbeBase):
    """
    class:`~google.cloud.storage.blob.Blob`
    method:`_do_upload`
    """
    def __init__(self, agent):
        ProbeBase.__init__(self, agent)
        self.agent = agent
        self.logger = agent.get_logger(__name__)

    def enter(self, instruction, context):
        if self.logger.isEnabledForTrace():
            self.logger.trace('StorageBlobUploadFile - enter')
        # the instrumented 'self' object  Iterator object
        # print 'args length:' + str(len(context.args))
        # print 'kwargs length:' + str(len(context.kwargs))
        blob_obj = context.args[0]
        bucket = blob_obj.bucket
        path = blob_obj.path
        context.set_data('path', path)  # path cannot be a signature key. Too many keys for every file in that case
        context.set_data('bucket', bucket.path, True)  # add just the bucket for signature key
        context.set_signature_type('Google Cloud Storage')

    def exit(self, instruction, context):
        if self.logger.isEnabledForTrace():
            self.logger.trace('StorageBlobUploadFile - exit')


class StorageBlobBase(ProbeBase):
    """
    class:`~google.cloud.storage.bucket.Bucket`
    method:`delete_blob`, 'get_blob'
    """
    def __init__(self, agent):
        ProbeBase.__init__(self, agent)
        self.agent = agent
        self.logger = agent.get_logger(__name__)

    def enter(self, instruction, context):
        if self.logger.isEnabledForTrace():
            self.logger.trace('StorageBlobBase - enter')
        # the instrumented 'self' object  Iterator object
        # print 'args length:' + str(len(context.args))
        # print 'kwargs length:' + str(len(context.kwargs))
        bucket = context.args[0]
        path = context.args[1]
        context.set_data('path', path)  # path cannot be a signature key. Too many keys for every file in that case
        context.set_data('bucket', bucket.path, True)  # add just the bucket for signature key
        context.set_signature_type('Google Cloud Storage')

    def exit(self, instruction, context):
        if self.logger.isEnabledForTrace():
            self.logger.trace('StorageBlobBase - exit')


#  Google Cloud Storage probes
class StorageBlobDelete(StorageBlobBase):
    """
    class:`~google.cloud.storage.bucket.Bucket`
    method:`delete_blob`
    """
    def __init__(self, agent):
        StorageBlobBase.__init__(self, agent)
        self.agent = agent
        self.logger = agent.get_logger(__name__)


class StorageGetBlob(StorageBlobBase):
    """
    class:`~google.cloud.storage.bucket.Bucket`
    method:`get_blob`
    """
    def __init__(self, agent):
        StorageBlobBase.__init__(self, agent)
        self.agent = agent
        self.logger = agent.get_logger(__name__)


class PubSubPublisherClientPublish(ProbeBase):
    """
    class:`~google.cloud.pubsub_v1.publisher.client.Client`
    method:`publish`
    TODO------------------------------------------------------------------------------------------------
    This probe uses setattr() to set the message values to the 'future' object, but it is more efficient to
    setattr during instrumentation of the Future class  -- google.cloud.pubsub_v1.publisher.futures.Future
    to create the property in the Future class and  then the value can be set in this probe
    TODO-------------------------------------------------------------------------------------------------
    """
    def __init__(self, agent):
        ProbeBase.__init__(self, agent)
        self.agent = agent
        self.logger = agent.get_logger(__name__)

    def enter(self, instruction, context):
        if self.logger.isEnabledForTrace():
            self.logger.trace('PubSubPublisherClientPublish - enter')
        # print 'args length:' + str(len(context.args))
        # print 'kwargs length:' + str(len(context.kwargs))
        topic = context.args[1]
        context.set_data('pubsub-topic', str(topic), True)
        context.set_signature_type('Google PubSub')

    def exit(self, instruction, context):
        if self.logger.isEnabledForTrace():
            self.logger.trace('PubSubPublisherClientPublish - exit')
        future = context.ret_val
        thread_local_stack = PrismoThreadLocalStack()
        corr_id = thread_local_stack.get_correlation_id()
        txn_id = thread_local_stack.get_txn_id()
        sequence = thread_local_stack.get_next_calling_sequence()
        # Todo : set the sequence in the this/previous "method context" object. (Exit point before this call)
        # Todo.. in this segment (caller) transaction. Then we can match caller exit point to transaction.
        # Todo : Otherwise right now we are just passing it to the called transaction in the header
        # Todo : When multiple calls are made to the same instance (from the same instance as well), we can;t correlate
        # Todo : otherwise
        # exit point id
        exit_point_id = uuid.uuid4().hex  # the exit_point_id is the caller_exit_point_id in the called transaction
        context.set_data(EXIT_POINT_ID, exit_point_id)
        txn_ext_dec = ExternalDecoratorContext()
        txn_ext_dec.is_embedded = False
        txn_ext_dec.set_entity_id("Google Pub/Sub")
        txn_ext_dec.set_correlation_id(corr_id)
        txn_ext_dec.set_sequence(sequence)
        txn_ext_dec.set_txn_id(txn_id)
        txn_ext_dec.set_caller_txn_id(txn_id)
        txn_ext_dec.set_caller_exit_point_id(exit_point_id)
        txn_ext_dec.set_data('Pub/Sub Topic Path', context.args[1], True)
        txn_ext_dec.set_data('node_type', 0)  # 0 = Entry point type
        setattr(future, 'txn_external_decoration', txn_ext_dec)


class PubSubPublisherFutureSetResult(ProbeBase):
    """
    class:`~google.cloud.pubsub_v1.publisher.futures.Future`
    method:`set_result`
    The probe will execute as the only one in its own thread.
    Since the 'transaction' will finish once this method pops out of the stack, the
    agent will queue its context data to be sent to the collector.
    We need to change the message type to be MessageType.external_correlation
    PrismoThreadLocalStack.set_external_correlation_decorator() will change this transaction to a
    correlation decoration and the message to the collector is an ExternalDecoratorContext
    """
    def __init__(self, agent):
        ProbeBase.__init__(self, agent)
        self.agent = agent
        self.logger = agent.get_logger(__name__)

    def enter(self, instruction, context):
        # print 'Entering callback for Publisher'
        if self.logger.isEnabledForTrace():
            self.logger.trace('PubSubPublisherFutureSetResult - enter')
        future_obj = context.args[0]
        message_id = context.args[1]
        txn_ext_dec = getattr(future_obj, 'txn_external_decoration')
        context.set_signature_type('Google Pub/Sub')
        if txn_ext_dec is not None:
            txn_ext_dec.set_data("Internal_NodeType", "Type_Entry")
            txn_ext_dec.add_correlation_key('message_id')
            txn_ext_dec.set_data('message_id', str(message_id)) # used to create the entry point id
            txn_ext_dec.set_entry_point_type("Google Pub/Sub")
            stack = PrismoThreadLocalStack()
            stack.set_external_correlation_decorator(txn_ext_dec)
            # print "Stack with ext corr in publisher: " + str(message_id)
            if self.logger.isEnabledForTrace():
                self.logger.trace('PubSubPublisherFutureSetResult - MessageID' + str(message_id))

    def exit(self, instruction, context):
        if self.logger.isEnabledForTrace():
            self.logger.trace('PubSubPublisherFutureSetResult - exit')


class PubSubSubscriberClientSubscribe(ProbeBase):
    """
    class:`~google.cloud.pubsub_v1.subscriber.client.Client`
    method:`subscribe`
     This probe instruments the callback(Callable); which is a what is called by a separate thread to process with
    a single parameter - Message object
    The probe should pass an instance of a class that must implement the __call__() method
    and wrap the original function object because if the callable is not an object instance of a class, then..
    instrumentation does not work for global functions which is imported like: from xxx_module import callable_function
    The callable class we use can be instrumented by another probe that can do the works like a regular probe
    transactions.
    TODO------------------------------------------------------------------------------------------------
    Future work:
    If the callback implements a base class and we should be instrumenting via the Base attribute of instrumentation
    instructions but currently instrumentation engine does not support inheritance.
    TODO-------------------------------------------------------------------------------------------------
    """
    def __init__(self, agent):
        ProbeBase.__init__(self, agent)
        self.agent = agent
        self.logger = agent.get_logger(__name__)

    def enter(self, instruction, context):
        if self.logger.isEnabledForTrace():
            self.logger.trace('PubSubSubscriberClientSubscribe - enter')
        # print 'args length:' + str(len(context.args))
        # print 'kwargs length:' + str(len(context.kwargs))
        subscription = context.args[1]
        context.set_signature_type('Google PubSub')
        if len(context.args) > 2:
            callback = context.args[2]
            wrapped_callback = PubSubSubscriberCallbackWrapper(subscription, callback)
            args_list = list(context.args)
            args_list[2] = wrapped_callback  # replace the callback with the wrapper
            context.set_args(args_list)  # set the new args
        else:
            callback = context.kwargs['callback']
            wrapped_callback = PubSubSubscriberCallbackWrapper(subscription, callback)
            kwargs_map = dict(**context.kwargs)
            # print 'Converted to dictionary'
            kwargs_map['callback'] = wrapped_callback   # replace the callback with the wrapper
            context.set_kwargs(**kwargs_map)       # set the new args

    def exit(self, instruction, context):
        if self.logger.isEnabledForTrace():
            self.logger.trace('PubSubSubscriberClientSubscribe - exit')


class PubSubSubscriberCallbackWrapper:
    """
    A wrapper meant for the callback registered with pubsub.
    This class is a 'Callable' and simply calls the application callback
    It provides an instrumentation point for the agent when the callback is a function
    and is imported in the code invoking it via : "from <module> import <callback function>
    Instrumenting this function is difficult as the module which imported this function
    now has it as an attribute not the the module where the function is written.
    """
    def __init__(self, subscription, callback):
        self._subscription = subscription
        self._callback = callback

    def __call__(self, *args, **kwargs):
        """
        Instrument this method with a probe to capture its transaction. This method
        will in all probability be the bottom of the call stack, and will be the entry point
        :param args: Message object
        :param kwargs:
        :return:
        """
        # print 'PubSubSubscriberCallbackWrapper'
        self._callback(*args, **kwargs)


class PubSubSubscriberCallback(ProbeBase):
    """
    class:`~prismo.core.probes.google.PubSubSubscriberCallbackWrapper`
    method:`__call__`
    This probe is instrumented into a Prismo class - since it is a wrapper around a Callable
    that is an instance and cannot be instrumented traditionally.
    The wrapper simply passes the call into the actual Callable.
    """
    def __init__(self, agent):
        ProbeBase.__init__(self, agent)
        self.agent = agent
        self.logger = agent.get_logger(__name__)

    def enter(self, instruction, context):
        """
        Currently we set the data as fields. We need to pass ExternalDecorators as the current scheme prevents
        the same tx making 2 calls with the same external_correlation_key.
        Should pass the message_id as the caller_tx_id and caller_exit_point_id , as well
        the fact that the other side (caller_exit_point) needs to be created. Pass a data map
        with its own fields. Ideally pass an embedded ExternalDecorator in the transaction context
        :param instruction:
        :param context:
        :return:
        """
        if self.logger.isEnabledForTrace():
            self.logger.trace('PubSubSubscriberCallback - enter')
        context.set_signature_type('Google PubSub')
        callback_wrapper = context.args[0]
        subscription = callback_wrapper._subscription
        message = context.args[1]
        if message is not None:
            message_id = message.message_id
            stack = PrismoThreadLocalStack()
            stack.set_data('message_id', message_id)
            stack.set_data('subscription', subscription, True)
            stack.set_entry_point_type('Pub/Sub Subscription')

            # should pass along enough to construct an ExternalDecoratorContext on server side
            # corr_key_list = stack.get_data('external_correlation_keys')
            # if corr_key_list is None:
            #     # print 'Correlation keys was None'
            #     stack.set_data('external_correlation_keys', [])
            #     corr_key_list = stack.get_data('external_correlation_keys')
            # corr_key_list.append('message_id')
            # stack.set_data('external_correlation_keys', corr_key_list)

            # corr_key_list = str(stack.get_data('external_correlation_keys'))
            # print 'Added key: ' + corr_key_list

            txn_ext_dec = ExternalDecoratorContext()
            txn_ext_dec.set_correlation_id(stack.get_correlation_id())
            txn_ext_dec.set_sequence(stack.get_next_calling_sequence())
            txn_ext_dec.set_txn_id(message_id)   # no not needed
            txn_ext_dec.set_caller_txn_id(message_id)   # no not needed
            txn_ext_dec.set_entity_id("Google Pub/Sub")
            txn_ext_dec.set_caller_exit_point_id(message_id)
            txn_ext_dec.set_data('Pub/Sub Subscription', subscription, True)
            txn_ext_dec.set_data("Internal_NodeType", "Type_Exit")
            txn_ext_dec.add_correlation_key('message_id')   # used to get entry point id for the exit point
            txn_ext_dec.set_data('message_id', message_id)
            txn_ext_dec.is_embedded = True
            txn_ext_dec.set_data('node_type', 1)  # 1 = Exit point type
            stack.set_external_correlation_decorator(txn_ext_dec)

            if self.logger.isEnabledForTrace():
                self.logger.trace('PubSubSubscriberCallback - MessageID' + str(message_id))

    def exit(self, instruction, context):
        if self.logger.isEnabledForTrace():
            self.logger.trace('PubSubSubscriberCallback - exit')


class BigTableReadRow(ProbeBase):
    """
    class:`~google.cloud.bigtable.table.Table`
    method:_`read_row`
    """
    def __init__(self, agent):
        ProbeBase.__init__(self, agent)
        self.agent = agent
        self.logger = agent.get_logger(__name__)

    def enter(self, instruction, context):
        if self.logger.isEnabledForTrace():
            self.logger.trace('BigTableReadRow - enter')
        # the instrumented 'self' object  Iterator object
        context.set_signature_type('Google BigTable')
        table_obj = context.args[0]
        context.set_data('table_name', table_obj.name, True)
        try:
            context.set_data('app_profile_id', table_obj.app_profile_id, True)
        except Exception:
            pass
        if len(context.args) > 2 and context.args[2] is not None:
            context.set_data('filter', str(context.args[2].to_pb()), True)

    def exit(self, instruction, context):
        if self.logger.isEnabledForTrace():
            self.logger.trace('BigTableReadRow - exit')


class BigTableReadRows(ProbeBase):
    """
    class:`~google.cloud.bigtable.table.Table`
    method:_`read_row`
    """
    def __init__(self, agent):
        ProbeBase.__init__(self, agent)
        self.agent = agent
        self.logger = agent.get_logger(__name__)

    def enter(self, instruction, context):
        if self.logger.isEnabledForTrace():
            self.logger.trace('BigTableReadRows - enter')
        # the instrumented 'self' object  Iterator object
        context.set_signature_type('Google BigTable')
        table_obj = context.args[0]
        context.set_data('table_name', table_obj.name, True)
        try:
            context.set_data('app_profile_id', table_obj.app_profile_id, True)
        except Exception:
            pass
        if len(context.args) > 4 and context.args[4] is not None:
            context.set_data('filter', str(context.args[4].to_pb()), True)

    def exit(self, instruction, context):
        if self.logger.isEnabledForTrace():
            self.logger.trace('BigTableReadRows - exit')


class BigTableBase(ProbeBase):
    """
    class:`~google.cloud.bigtable.table.Table`
    method:_`mutate_rows`
    method: 'delete'
    method: 'create'
    method: 'exists'
    method: 'truncate'
    method: 'sample_row'
    """
    def __init__(self, agent):
        ProbeBase.__init__(self, agent)
        self.agent = agent
        self.logger = agent.get_logger(__name__)

    def enter(self, instruction, context):
        if self.logger.isEnabledForTrace():
            self.logger.trace('BigTableBase - enter')
        # the instrumented 'self' object  Iterator object
        context.set_signature_type('Google BigTable')
        table_obj = context.args[0]
        context.set_data('table_name', table_obj.name, True)
        try:
            context.set_data('app_profile_id', table_obj.app_profile_id, True)
        except Exception:
            pass

    def exit(self, instruction, context):
        if self.logger.isEnabledForTrace():
            self.logger.trace('BigTableBase - exit')


class BigTableDropByPrefix(ProbeBase):
    """
    class:`~google.cloud.bigtable.table.Table`
    method:_`drop_by_prefix`
    """
    def __init__(self, agent):
        ProbeBase.__init__(self, agent)
        self.agent = agent
        self.logger = agent.get_logger(__name__)

    def enter(self, instruction, context):
        if self.logger.isEnabledForTrace():
            self.logger.trace('BigTableDropByPrefix - enter')
        # the instrumented 'self' object  Iterator object
        context.set_signature_type('Google BigTable')
        table_obj = context.args[0]
        prefix = context.args[1]
        context.set_data('table_name', table_obj.name, True)
        context.set_data('prefix', prefix, True)
        try:
            context.set_data('app_profile_id', table_obj.app_profile_id, True)
        except Exception:
            pass

    def exit(self, instruction, context):
        if self.logger.isEnabledForTrace():
            self.logger.trace('BigTableDropByPrefix - exit')



