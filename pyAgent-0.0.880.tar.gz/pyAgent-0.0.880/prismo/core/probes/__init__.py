#!/usr/bin/env python
__copyright__ = """
* Copyright (c) 2018 Prismo Systems . All rights reserved.
"""

__author__ = 'Ramesh Mani'


class ProbeBase:
    """
    probes should decorate the following as well
     - Type : Entry/Exit/Middle
     - Sub Type : Servlet/Database/RestClient/etc .. as new probes are written to cover additional Entry/Exit points
     The Type will be used to lookup a list of keys for the type to form the signature.
     This lookup set is in the server and agent does not need to send it.
    """
    TYPE = 'Type'
    SUB_TYPE = 'Sub_Type'
    TYPE_ENTRY = 'Entry'
    TYPE_EXIT = 'Exit'
    TYPE_MIDDLE = 'Middle'

    def __init__(self, agent):
        pass

    # instruction is the raw instruction array.
    def enter(self, instruction, context):
        # add trace log
        pass

    def exit(self, instruction, context):
        pass


# Used when unable to load a Probe module code
class ProbeCodeStub (ProbeBase):
    def __init__(self, agent):
        ProbeBase.__init__(self, agent)
        pass

    def enter(self, instruction, context):
        # add trace log
        pass

    def exit(self, instruction, context):
        pass

