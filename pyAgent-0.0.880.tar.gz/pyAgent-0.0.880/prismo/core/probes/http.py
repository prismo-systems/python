#!/usr/bin/env python

__copyright__ = """
* Copyright (c) 2018 Prismo Systems . All rights reserved.
*
"""

__author__ = 'Ramesh Mani'
from prismo.core.probes import ProbeBase
import importlib
from prismo.api.constants import HTTP_CORRELATION_HEADER_KEY, HTTP_CORRELATION_SEQUENCE, \
    HTTP_CORRELATION_CALLER_TXN_ID, EXIT_POINT_ID, CALLER_EXIT_POINT_ID
from prismo.core.transaction import PrismoThreadLocalStack
from prismo.core.transaction import METHOD_ENTRY_POINT
from os import environ
import uuid

net_user_map = {'10.0.2.200': 'Ramesh Mani', '10.0.17.11': 'Dev User'}
app_user_map = {'10.0.2.200': 'rmani', '10.0.17.11': 'admin'}


class HttpRequest(ProbeBase):
    """
    probes should decorate the following as well
     - Type : Entry/Exit/Middle
     - Sub Type : Servlet/Database/RestClient/etc .. as new probes are written to cover additional Entry/Exit points
     The Type will be used to lookup a list of keys for the type to form the signature.
     This lookup set is in the server and agent does not need to send it.

     For the query parameters see
     C:\Users\rmix\.virtualenvs\prismo-server\Lib\site-packages\werkzeug\wrappers.py - BaseRequest..
    """
    def __init__(self, agent):
        ProbeBase.__init__(self, agent)
        self.agent = agent
        self.logger = agent.get_logger(__name__)
        # Load the required library modules specific to this probe from the frameworks
        # Get the LocalStack that werkzeug provides , 'is a thread local' equivalent that handles greenlets as well
        # so it is always updated for the current thread/greenlet as inspite of us loading it in the
        # probe constructor which is done only once!
        self._request_ctx_stack = getattr(importlib.import_module('flask.globals'), '_request_ctx_stack', False)

    def enter(self, instruction, context):
        # print 'HttpRequest enter*****' + str(instruction)
        if self.logger.isEnabledForTrace():
            self.logger.trace('HttpProbe - enter')
        # the instrumented 'self' object  flask.app.Flask
        # flask_app_obj = context.args[0]   # we don't need it right now

        # access the request object flask.ctx.RequestContext.request
        # where RequestContext = self._request_ctx_stack.top
        prismo_http_corr_id = None
        # app = self._request_ctx_stack.top.app
        # app_name =  app.name()
        request_obj = self._request_ctx_stack.top.request
        context.set_signature_type(METHOD_ENTRY_POINT)
        context.set_data('Http Method', request_obj.method, True)
        context.set_data('URL', request_obj.path, True)
        # print 'Request Path: ' + request_obj.path
        # context.set_data('URL', request_obj.base_url, True)
        context.set_data('Remote Address', str(request_obj.remote_addr))
        context.set_data('User Agent', str(request_obj.user_agent))
        context.set_data('user_ip', str(request_obj.remote_addr))
        app_user = app_user_map.get(str(request_obj.remote_addr))
        net_user = net_user_map.get(str(request_obj.remote_addr))
        if app_user:
            context.set_data('app_user', app_user)
        if net_user:
            context.set_data('user_name', net_user)
        # query params
        if len(request_obj.args) > 0:   # using request_obj.values will give both query and form params
            query_param_sig_attr = ""   # we use just the count of both for now. This should make it unique enough
            for k in request_obj.args:
                v = request_obj.args.get(k)
                query_param_event_rec = 'query_param__' + k
                context.set_data(query_param_event_rec, v)    # added to event rec
                query_param_sig_attr += k + '&'
            context.set_data('query_param', query_param_sig_attr, True)      # added to sig attribute
        if len(request_obj.values) > 0:   # using request_obj.values will give both query and form params
            post_param_sig_attr = ""      # lets get the first 20 (can be a too many.. need to clamp)
            param_counter = 0
            for k in request_obj.values:
                v = request_obj.values.get(k)
                post_param_event_rec = 'post_param__' + k
                context.set_data(post_param_event_rec, v)    # added to event rec
                post_param_sig_attr += k + '&'
                param_counter += 1
                if param_counter > 20:
                    break
            context.set_data('post_param', post_param_sig_attr, True)      # added to sig attribute

        context.set_data('param_count', str(len(request_obj.values)), True)
        # if self.logger.isEnabledForTrace():
        #     self.logger.trace('Within Http Probe: ' + str(request_obj))
        thread_local_stack = PrismoThreadLocalStack()
        thread_local_stack.set_entry_point_type('Http')
        if request_obj.headers is not None:
            # print 'Headers: ' + str(request_obj.headers)
            # print 'Headers-by key - Host: ' + request_obj.headers.get('Host')
            # print 'Existing thread CorID!!!!!!-------' + thread_local_stack.get_correlation_id()

            caller_exit_point_id = request_obj.headers.get(CALLER_EXIT_POINT_ID)
            if caller_exit_point_id is not None:
                thread_local_stack.set_caller_exit_point_id(caller_exit_point_id)

            prismo_http_corr_id = request_obj.headers.get(HTTP_CORRELATION_HEADER_KEY)
            if prismo_http_corr_id is None:
                prismo_http_corr_id = thread_local_stack.get_correlation_id()
            else:
                caller_txn_id = request_obj.headers.get(HTTP_CORRELATION_CALLER_TXN_ID)
                sequence = request_obj.headers.get(HTTP_CORRELATION_SEQUENCE)
                thread_local_stack.set_correlation_id(prismo_http_corr_id)
                thread_local_stack.set_caller_txn_id(caller_txn_id)
                thread_local_stack.set_sequence(sequence)
        if self.logger.isEnabledForTrace():
            self.logger.trace('PRISMO_HTTP_CORR_ID: ' + prismo_http_corr_id)

    def exit(self, instruction, context):
        # print 'Http -exit ***'
        if self.logger.isEnabledForTrace():
            self.logger.trace('HttpProbe - exit')


# for requests client  - requests.models.Request
# instrument the constructor
class HttpRequestsCorrelation(ProbeBase):
    def __init__(self, agent):
        ProbeBase.__init__(self, agent)
        self.agent = agent
        self.logger = agent.get_logger(__name__)
        self.skip_header = False
        if environ.get("prismo_skip_rest_header"):
            self.skip_header = True
        # lets load the required library modules specific to this probe from the frameworks

    def enter(self, instruction, context):
        # class Request(RequestHooksMixin):
        #     """A user-created :class:`Request <Request>` object.
        #
        #     Usage::
        #
        #       >>> import requests
        #       >>> req = requests.Request('GET', 'http://httpbin.org/get')
        #       >>> req.prepare()
        #       <PreparedRequest [GET]>
        #     """
        #
        #     def __init__(self,
        #                  method=None, url=None, headers=None, files=None, data=None,
        #                  params=None, auth=None, cookies=None, hooks=None, json=None):
        if self.logger.isEnabledForTrace():
            self.logger.trace('HttpRequestsCorrelation - enter')

    # At the end of the constructor, we need to add the Correlation ID, caller_txn_id, sequence and caller_exit_point_id
    # to the outgoing Http request
    # The caller_exit_point_d is created by this exit point and is part of the data for this exit point as well.
    # Todo : set the sequence in the this/previous method context object. (Exit point before this call)
    def exit(self, instruction, context):
        if self.logger.isEnabledForTrace():
            self.logger.trace('HttpRequestsCorrelation - exit')
        # constructor finished executing, now lets modify the 'self' object which is args[0]
        request_obj = context.args[0]
        thread_local_stack = PrismoThreadLocalStack()
        prismo_http_corr_id = thread_local_stack.get_correlation_id()
        this_txn_id = thread_local_stack.get_txn_id()
        sequence = thread_local_stack.get_next_calling_sequence()
        exit_point_id = uuid.uuid4().hex  # the exit_point_id is the caller_exit_point_id in the called transaction
        context.set_data(EXIT_POINT_ID, exit_point_id)
        context.set_data('URL', request_obj.url, True)       # TODO : URL needs to be normalized
        context.set_data('Http Method', request_obj.method, True)
        context.set_signature_type('REST API')

        # Debug - dump header
        # str_log = self.log_request_object(request_obj)
        if self.skip_header:
            # self.logger.info(str_log)
            return
        request_obj.headers[CALLER_EXIT_POINT_ID] = exit_point_id
        request_obj.headers[HTTP_CORRELATION_HEADER_KEY] = prismo_http_corr_id
        request_obj.headers[HTTP_CORRELATION_CALLER_TXN_ID] = this_txn_id
        request_obj.headers[HTTP_CORRELATION_SEQUENCE] = str(sequence)
        # str_log += self.log_request_object(request_obj)
        # self.logger.info(str_log)
        # print 'Http Method: ' + request_obj.method
        # print 'Url: ' + request_obj.url
        if self.logger.isEnabledForTrace():
            self.logger.trace('Header decorated - PRISMO_HTTP_CORR_ID: ' + prismo_http_corr_id)

    def log_request_object(self, request_obj):
        str_log = "   ______HttpCorrelation: " + request_obj.url
        for k in request_obj.headers:
            str_log += " Key: " + str(k) + " Value:" + str(request_obj.headers[k])
        return str_log

