import os
from prismo.constants import PYAGENT_CFG, PYAGENT_PROBE_CFG, PRINT_PREFIX, LOGGER_NAME
from prismo.constants import TYPE_PROBE, TYPE_INSTRUCTION, MODULE, CLASS, METHOD, BASE, NAME, \
    INSTRUMENTATION_INSTRUCTION_KEYWORDS, TYPE_SKIP, PROBE, TYPE_SERVICE
from prismo.util.pattern import Singleton


logger = None

# Loads the defaults from the bundled file
# next loads the properties from the file given in the environment variable (override the defaults)
# next looks for environment variables matching the loaded properties (override the last value.
# therefor order of precedence:
# 1 -environment variable,
# 2 -custom config file,
# 3 -default config


class AgentConfig (Singleton):
    def __init__(self, agent):
        self.properties = {}
        self.config_file_time = 0
        self.agent = agent
        self.logger = self.agent.get_logger(__name__)

    def load_agent_config(self):
        environ = os.environ
        # first load default from bundled,
        import prismo.config as config
        file_path = os.path.join(os.path.dirname(os.path.realpath(config.__file__)), 'pyagent.cfg')
        self.load_config_from_file(file_path)

        # next load the custom config
        if PYAGENT_CFG in environ:
            # load custom config
            self.load_config_from_file(environ[PYAGENT_CFG])

        # load properties from environment variables
        # print key n values
        for k in self.properties:
            if k in environ:
                self.properties[k] = environ[k]
                self.logger.info('Environment variable overrides : {0},  value : {1}'.format(k, self.properties[k]))

    def load_config_from_file(self, file_path):
        file_handle = None
        try:
            # print 'Reading config..' + file_path
            file_handle = open(file_path, 'r')
            config_data = file_handle.readlines()
            self.set_properties(config_data)
            self.config_file_time = os.path.getmtime(file_path)
        except Exception as e:
            # print 'Exception load_config_from_file' + e.message
            self.logger.error('Unable to read probe config file:' + ' '.join(file_path))
            self.logger.error(str(e))
        finally:
            if file_handle is not None:
                file_handle.close()

    def set_properties(self, file_data):
        line_num = 1
        for line in file_data:
            line_num += 1
            if not line.startswith('#') and not line.startswith('\n'):
                try:
                    k, v_ = line.strip('\n').split('=', 1)
                    if k is not None and v_ is not None:
                        self.properties[k] = v_
                    else:
                        self.logger.warn(' Probe config format error in line:' + str(line_num) + '. Ignoring line')
                finally:
                    pass

    def get_property(self, name, default=None):
        value = self.properties.get(name)
        if value is None:
            return default
        return value


class InstrumentationConfig (Singleton):
    def __init__(self, agent):
        self.service_definitions = []
        self.probe_definitions = {}
        self.instructions = {}
        self.direct_modules = []             # list of modules with direct instructions (no base)
        self.base_class_instructions = {}
        self.skip_instructions = {MODULE: [], CLASS: [], NAME: []}
        self.config_file_time = 0
        self.agent = agent
        self.logger = self.agent.get_logger(__name__)

    def get_service_definitions(self):
        return self.service_definitions

    def get_probe_definition(self, probe_name):
        return self.probe_definitions.get(probe_name)

    def should_skip_module(self, module_name):
        if module_name is not None and module_name in self.skip_instructions[MODULE]:
            return True
        else:
            return False

    def should_skip_class(self, class_name):
        if class_name is not None and class_name in self.skip_instructions[CLASS]:
            return True
        else:
            return False

    def should_skip_instruction(self, instruction_name):
        if instruction_name is not  None and instruction_name in self.skip_instructions[NAME]:
            return True
        else:
            return False

    def matches_module_instrumentation(self, module_name):
        if module_name is not None and module_name in self.direct_modules:
            return True
        else:
            return False

    def has_instrumentation_instructions(self):
        return len(self.instructions.keys()) > 0

    def get_instruction_names(self):
        return self.instructions.keys()

    def get_instruction(self, name):
        return self.instructions.get(name)

    def load_instrumentation_config(self):
        environ = os.environ
        # first load default from bundled,
        import prismo.config as config
        file_path = os.path.join(os.path.dirname(os.path.realpath(config.__file__)), 'probe.cfg')
        self.load_config_from_file(file_path)

        # next load the custom config
        if PYAGENT_PROBE_CFG in environ:
            # load custom config
            self.load_config_from_file(environ[PYAGENT_PROBE_CFG])

        # TODO Override thru environment variable not supported for now. Maybe a good idea to do so
        # # load properties from environment variables
        # # print key n values
        # for k in self.properties:
        #     if k in environ:
        #         self.properties[k] = environ[k]
        #         print "Environment variable overrides : {0},  value : {1}".format(k, self.properties[k])

    def load_config_from_file(self, file_path):
        try:
            # print 'Reading Instrumentation config...'
            file_handle = open(file_path, 'r')
            config_data = file_handle.readlines()
            self.parse_config_data(config_data)
            self.config_file_time = os.path.getmtime(file_path)
        except Exception as e:
            # print 'exception --Instrumentation config' + e.message
            self.logger.error('Unable to read config file:' + ' '.join(file_path))
            self.logger.error(str(e))
        finally:
            if file_handle is not None:
                file_handle.close()

    def parse_config_data(self, file_data):
        # Add logging
        line_num = 1
        for line in file_data:
            if line.startswith('#') or line.startswith('\n'):
                line_num += 1
                continue
            # line = line.replace(' ', '')

            if not line.startswith(TYPE_PROBE) and not line.startswith(TYPE_INSTRUCTION) \
                    and not line.startswith(TYPE_SKIP) and not line.startswith(TYPE_SERVICE):
                self.logger.warn('Invalid probe config in line ' + str(line_num) + '. Line Ignored')
                line_num += 1
                continue

            try:
                self.logger.info('Parsing line: ' + str(line_num) + ' ' + line)
                key, value = line.split('=')

                value = value.strip('{}\r\n')
                values = value.split(',')
                if key == TYPE_PROBE:
                    self.parse_probe_definition(line_num, values)
                elif key == TYPE_INSTRUCTION:
                    self.parse_instrumentation_instruction(line_num, values)
                elif key == TYPE_SERVICE:
                    self.parse_service_definition(line_num, values)
                else:
                    self.parse_skip_instruction(line, values)

            except Exception as e:
                self.logger.error(':Error parsing line ' + str(line_num) + '. Line Ignored')
                self.logger.error(str(e))
            line_num += 1

    def parse_instrumentation_instruction(self, line_num, values):
        # add instruction
        self.logger.info('Parsing instrumentation instruction on line:' + str(line_num) + ' ' + str(values))
        instruction = {}
        for words in values:
            # split into individual components
            k, v = words.split(":")
            # uppercase for keywords
            k = k.strip(' ')
            if str(k).lower() in INSTRUMENTATION_INSTRUCTION_KEYWORDS:
                k = str(k).lower()
            instruction[k.strip(' ')] = v.strip(' ')
        # validate probe_dec
        if not self.validate_instrumentation_instruction(instruction):
            self.logger.warn('Invalid instrumentation instruction in line: ' + str(line_num) + '. Line Ignored')
        else:
            if str(instruction[BASE]) == 'True':
                self.base_class_instructions[instruction[NAME]] = instruction
            else:
                self.instructions[instruction[NAME]] = instruction
                self.direct_modules.append(instruction[MODULE])
                self.logger.debug('Added Instruction' + str(instruction))

    def parse_probe_definition(self, line_num, values):
        # add probe
        self.logger.info('Parsing probe definition on line:' + str(line_num) + ' ' + str(values))
        probe_dec = {}
        for words in values:
            # split into individual components
            k, v = words.split(":")
            probe_dec[k.strip(' ')] = v.strip(' ')
        # validate probe_dec
        if not self.validate_probe_definition(probe_dec):
            self.logger.warn('Invalid probe declaration in line: ' + str(line_num) + '. Line Ignored')
        else:
            self.probe_definitions[probe_dec[NAME]] = probe_dec
            self.logger.debug('Added Probe' + str(probe_dec))

    def parse_service_definition(self, line_num, values):
        # add probe
        self.logger.info('Parsing service definition on line:' + str(line_num) + ' ' + str(values))
        service_def = {}
        for words in values:
            # split into individual components
            k, v = words.split(":")
            service_def[k.strip(' ')] = v.strip(' ')
        # validate probe_dec
        if not self.validate_service_definition(service_def):
            self.logger.warn('Invalid service declaration in line: ' + str(line_num) + '. Line Ignored')
        else:
            self.service_definitions.append(service_def)
            self.logger.debug('Added Service Definition' + str(service_def))

    def parse_skip_instruction(self, line_num, values):
        # add probe
        if len(values) > 1:
            self.logger.warn('Invalid skip instruction in line: ' + str(line_num) + '. Line Ignored')
            return
        k, v = values.split(":")
        type_of_skip = k.strip(' ')
        type_of_skip = str(type_of_skip).lower()
        # validate probe_dec
        if type_of_skip not in [MODULE, CLASS, NAME]:
            self.logger.warn('Invalid skip instruction in line: ' + str(line_num) + '. Line Ignored')
        else:
            self.skip_instructions[type_of_skip].append(v.strip(' '))

    @staticmethod
    def validate_probe_definition(probe_dec):
        if probe_dec[NAME] is not None and \
            probe_dec[MODULE] is not None and \
                probe_dec[CLASS] is not None:
            return True
        else:
            return False

    @staticmethod
    def validate_service_definition(probe_dec):
        if probe_dec[NAME] is not None and \
            probe_dec[MODULE] is not None and \
                probe_dec[CLASS] is not None:
            return True
        else:
            return False

    def validate_instrumentation_instruction(self, instruction):
        # check it has a probe
        if instruction[NAME] is None:
            self.logger.warn(' Missing Name attribute!')
            return False
        if instruction[PROBE] is None:
            self.logger.warn('Missing probe attribute! ')
            return False
        if instruction[MODULE] is None:
            self.logger.warn(' Missing module attribute!')
            return False
        if instruction[METHOD] is None:
            self.logger.warn(' Missing method attribute!')
            return False
            # this has module. can be direct or base
        if str(instruction[BASE]) == 'True':
            # base class instrumentation
            if instruction[CLASS] is None:
                # invalid
                self.logger.warn('Instruction with base=True requires a class attribute!')
                return False
            else:
                # this is direct
                pass
        return True

