#!/usr/bin/env python

__copyright__ = """
* Copyright (c) 2018 Prismo Systems . All rights reserved.
*
"""

__author__ = 'Ramesh Mani'

from prismo.core.probes import ProbeBase
from prismo.api.constants import HTTP_CORRELATION_HEADER_KEY, HTTP_CORRELATION_SEQUENCE, \
    HTTP_CORRELATION_CALLER_TXN_ID, EXIT_POINT_ID, CALLER_EXIT_POINT_ID
from prismo.core.transaction import PrismoThreadLocalStack
import uuid

try:
    urllib2enabled = True
    import urllib2
except Exception as e:
    urllib2enabled = False


try:
    import urllib
    urllib_enabled = True
except Exception as e2:
    urllib_enabled = False

try:
    import urllib.request
    urllib_request_enabled = True
except Exception as e2:
    urllib_request_enabled = False

try:
    urllib3enabled = True
    import urllib3
except Exception as e:
    urllib3enabled = False


class Urllib2Urlopen(ProbeBase):
    """
        This probe instruments urllib2.urlopen to capture the outgoing URL.
    """
    def __init__(self, agent):
        super().__init__(agent)
        self.agent = agent
        self.logger = agent.get_logger(__name__)
        if not urllib2enabled:
            self.urllib2enabled = False
        else:
            self.urllib2enabled = True

    def enter(self, instruction, context):
        # print "Urllib2Urlopen - enter : " + str(instruction)
        if self.logger.isEnabledForTrace():
            self.logger.trace('Urllib2Urlopen - enter')
        url = context.args[0]  # index 0 as its package method. (No instance) this could be a Request object.
        # print ('Check instance type: ' + str(self.urllib2enabled))
        if self.urllib2enabled and isinstance(url,  urllib2.Request):
            url = url.get_full_url()
            # print ('Check instance type 2 ' + str(url))

        context.set_signature_type("Client_Socket")
        context.set_data('URL', str(url), True)

    def exit(self, instruction, context):
        if self.logger.isEnabledForTrace():
            self.logger.trace('Urllib2Urlopen - exit')


class Urllib3Request(ProbeBase):
    """
        This probe instruments urllib2.urlopen to capture the outgoing URL.
    """
    def __init__(self, agent):
        super().__init__(agent)
        self.agent = agent
        self.logger = agent.get_logger(__name__)
        if not urllib3enabled:
            self.urllib3enabled = False
        else:
            self.urllib3enabled = True

    def enter(self, instruction, context):
        # print "Urllib2Urlopen - enter : " + str(instruction)
        if self.logger.isEnabledForTrace():
            self.logger.trace('Urllib3Request - enter')
        url = context.args[2]  # index 0 as its package method. (No instance) this could be a Request object.
        # print ('Check instance type: ' + str(self.urllib2enabled))
        if self.urllib3enabled and isinstance(url, urllib3.Request):
            url = url.get_full_url()
            # print ('Check instance type 2 ' + str(url))

        context.set_signature_type("Client_Socket")
        context.set_data('URL', str(url), True)

    def exit(self, instruction, context):
        if self.logger.isEnabledForTrace():
            self.logger.trace('Urllib2Urlopen - exit')


class UrllibUrlopen(ProbeBase):
    """
        This probe instruments urllib.urlopen to capture the outgoing URL.
    """
    def __init__(self, agent):
        super().__init__(agent)
        self.agent = agent
        self.logger = agent.get_logger(__name__)

    def enter(self, instruction, context):
        if self.logger.isEnabledForTrace():
            self.logger.trace('Urllib.Urlopen - enter')
        url_arg = context.args[0]  # index 0 as its package method. (No instance) this could be a Request object.
        # print("Urllib2Urlopen - enter : got context " + str(url_arg))
        url = ""
        try:
            if isinstance(url_arg, urllib.request.Request):
                url = url_arg.get_full_url()
                # print("Urllib2Urlopen - enter : got context is request2")

            else:
                url = url_arg
                # print("Urllib2Urlopen - enter : got context is str2")
        except Exception as e:
            print ("Exception ! " + str(e))
            # traceback.print_exc(file=sys.stdout)

        context.set_signature_type("Client_Socket")

        context.set_data('URL', str(url), True)

    def exit(self, instruction, context):
        if self.logger.isEnabledForTrace():
            self.logger.trace('Urllib.Urlopen - exit')


class HttpConnection(ProbeBase):
    """
        This probe instruments HttpConnection.connect to capture the remote IP address.
        Should skip this for all calls except calls within Urllib2.Urlopen, Urllib.Urlopen
        The flag should be set by the Urllib2Urlopen.enter and reset in Urllib2Urlopen.exit (and others listed above)
    """
    def __init__(self, agent):
        super().__init__(agent)
        self.agent = agent
        self.skip_header = False
        self.logger = agent.get_logger(__name__)

    def enter(self, instruction, context):
        if self.logger.isEnabledForTrace():
            self.logger.trace('HttpConnection - enter')
        self.add_correlation_header(context)

    def exit(self, instruction, context):
        if self.logger.isEnabledForTrace():
            self.logger.trace('HttpConnection - exit')
        this_obj = context.args[0]
        if this_obj.sock is not None:
            ip_address = this_obj.sock.getpeername()[0]
            port = this_obj.sock.getpeername()[1]
            context.set_data('IpAddress', str(ip_address), True)
            context.set_data('Port', str(port), True)
            if self.logger.isEnabledForTrace():
                self.logger.trace('HttpConnection - exit: ' + str(ip_address))

    def add_correlation_header(self, context):
        if self.logger.isEnabledForTrace():
            self.logger.trace('HttpRequestsCorrelation - exit')
        # constructor finished executing, now lets modify the 'self' object which is args[0]
        headers = {}
        if len(context.args) < 5 :
            headers = context.kwargs['headers']
            if headers is None:
                # print ("No Headers")
                context.kwargs['headers'] = {HTTP_CORRELATION_HEADER_KEY: "_"}
                headers = context.kwargs['headers']
            # else:
            #     print ("Headers:" + str(headers))
        else:
            headers = context.args[4]
            # print ("Arg Headers:" + str(headers))
        thread_local_stack = PrismoThreadLocalStack()
        prismo_http_corr_id = thread_local_stack.get_correlation_id()
        this_txn_id = thread_local_stack.get_txn_id()
        sequence = thread_local_stack.get_next_calling_sequence()
        exit_point_id = uuid.uuid4().hex  # the exit_point_id is the caller_exit_point_id in the called transaction
        context.set_data(EXIT_POINT_ID, exit_point_id)
        # context.set_data('URL', request_obj.url, True)       # TODO : URL needs to be normalized
        # context.set_data('Http Method', request_obj.method, True)
        # context.set_signature_type('REST API')

        # Debug - dump header
        # str_log = self.log_request_object(request_obj)
        if self.skip_header:
            # self.logger.info(str_log)
            return
        headers[CALLER_EXIT_POINT_ID] = exit_point_id
        headers[HTTP_CORRELATION_HEADER_KEY] = prismo_http_corr_id
        headers[HTTP_CORRELATION_CALLER_TXN_ID] = this_txn_id
        headers[HTTP_CORRELATION_SEQUENCE] = str(sequence)
        # str_log += self.log_request_object(request_obj)
        # self.logger.info(str_log)
        # print 'Http Method: ' + request_obj.method
        # print 'Url: ' + request_obj.url
        # print ("Correlated--------------->:" + str(context.args[2]))
        if self.logger.isEnabledForTrace():
            self.logger.trace('Header decorated - PRISMO_HTTP_CORR_ID: ' + prismo_http_corr_id)
