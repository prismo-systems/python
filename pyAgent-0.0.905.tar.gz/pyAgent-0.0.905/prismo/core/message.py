#!/usr/bin/env python

__copyright__ = """
* Copyright (c) 2018 Prismo Systems . All rights reserved.
*
"""

__author__ = 'Ramesh Mani'
import json
import os
import socket


# Should implement __slots__ and getstate and setstate
# http://book.pythontips.com/en/latest/__slots__magic.html
# https://docs.python.org/2/library/pickle.html#object.__getstate__
class MessageEnvelope(object):
    process_id = os.getpid()
    application_entity = "Default Entity"
    container_id = ""

    def __init__(self, message_type):
        self.header = {MessageType.type_key: message_type, MessageHeaders.process_id: MessageEnvelope.process_id,
                       MessageHeaders.container_id: MessageEnvelope.container_id, MessageHeaders.agent_version: 835,
                       MessageHeaders.application_entity: MessageEnvelope.application_entity}
        self.payload = None

    @staticmethod
    def set_container_id(flag):
        if flag:
            MessageEnvelope.container_id = socket.gethostname()

    def add_header_attribute(self, name, value):
        self.header[name] = value

    def get_header(self):
        return self.header

    def get_header_attribute(self, name):
        return self.header.get(name)

    def add_payload(self, message_element):
        self.payload = message_element

    def __str__(self):
        return '{"header":' + json.dumps(self.header) + ', ' + repr(self.payload) + '}'

    def __repr__(self):
        return '{"header":' + json.dumps(self.header) + ', ' + repr(self.payload) + '}'

    # def __str__(self):
    #     return '{"header":' + json.dumps(self.header) + ',"payload":' + repr(self.payload) + '}'
    #
    # def __repr__(self):
    #     return '{"header":' + json.dumps(self.header) + ',"payload":' + repr(self.payload) + '}'


class MessageType:
    type_key = "Message_type"
    application = 0
    transaction = 1
    external_correlation = 2

    def __init__(self):
        pass


class MessageHeaders:
    process_id = "Process_Id"
    group_id = "Group_Id"
    agent_name = "Agent_Name"
    agent_version = 'Agent_Version'
    application_name = "Application_Name"
    application_entity = "Application_Entity"
    container_id = "Container_id"

    def __init__(self):
        pass


# Should implement __slots__ and getstate and setstate
# http://book.pythontips.com/en/latest/__slots__magic.html
# https://docs.python.org/2/library/pickle.html#object.__getstate__
class MessageBodyElement(object):

    def __init__(self, element_type):
        self.element_type = element_type

    def __str__(self):
        return 'Message Element Type ' + str(self.element_type)


class MessageElementType:
    application = 0
    transaction_context = 1
    method_context = 2
    external_decoration = 3

    def __init__(self):
        pass
