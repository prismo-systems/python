#!/usr/bin/env python
__copyright__ = """
* Copyright (c) 2018 Prismo Systems . All rights reserved.
*
"""

__author__ = 'Ramesh Mani'

from setuptools import setup, find_packages
# To use a consistent encoding
from codecs import open
from os import path

pwd = path.abspath(path.dirname(__file__))
# print ('Packages found :' + str(find_packages()))
with open(path.join(pwd, 'LICENSE.txt'), encoding='utf-8') as f:
    long_description = f.read()
setup(
    name='pyAgent',
    version='0.0.905',
    url='http://www.prismosystems.com',
    license='Annual License ' + long_description,
    author='Ramesh Mani',
    author_email='rmani@prismosystems.com',
    description='Python Agent',
    packages=find_packages(),
    classifiers=(
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ),

    # If there are data files included in your packages that need to be
    # installed, specify them here.  If using Python 2.6 or less, then these
    # have to be included in MANIFEST.in as well.
    include_package_data=True,
    package_data={
        'prismo': ['prismo/config/pyagent.cfg', 'prismo/config/probe.cfg', 'prismo/config/certfile.crt']
    },

    # Although 'package_data' is the preferred approach, in some case you may
    # need to place data files outside of your packages. See:
    # http://docs.python.org/3.4/distutils/setupscript.html#installing-additional-files # noqa
    # In this case, 'data_file' will be installed into '<sys.prefix>/my_data'
    # data_files=[('my_data', ['data/data_file'])],
    data_files=[],

    # To provide executable scripts, use entry points in preference to the
    # "scripts" keyword. Entry points provide cross-platform support and allow
    # pip to create the appropriate form of executable for the target platform.
    entry_points={
            'console_scripts': [
                'prismopy = prismo:main',
            ],
    }
)

