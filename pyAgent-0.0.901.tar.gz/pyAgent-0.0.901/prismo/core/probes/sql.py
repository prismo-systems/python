#!/usr/bin/env python

__copyright__ = """
* Copyright (c) 2018 Prismo Systems . All rights reserved.
*
"""

__author__ = 'Ramesh Mani'

from prismo.core.probes import ProbeBase
from prismo.constants import METHOD


class SqlAlchemyConnection(ProbeBase):
    """
    probes should decorate the following as well
     - Type : Entry/Exit/Middle
     - Sub Type : Servlet/Database/RestClient/etc .. as new probes are written to cover additional Entry/Exit points
     The Type will be used to lookup a list of keys for the type to form the signature.
     This lookup set is in the server and agent does not need to send it.
    """
    def __init__(self, agent):
        super().__init__(agent)
        self.agent = agent
        self.logger = agent.get_logger(__name__)

    def enter(self, instruction, context):
        # The method instrumented has the following signature
        # def _execute_context(self, dialect, constructor, statement, parameters, *args):
        # print 'SqlAlchemyConnection - enter'
        if instruction[METHOD] == '_execute_context':
            if self.logger.isEnabledForTrace():
                self.logger.trace('_execute_context - extracting SQL and params')
            statement = context.args[3]
            context.set_data('__RAD_SQL_STATEMENT__SQL', str(statement), True)
            context.set_data('__RAD_SQL_STATEMENT__SQL', str(statement), False)

    def exit(self, instruction, context):
        if self.logger.isEnabledForTrace():
            self.logger.trace('SqlAlchemy - exit')
