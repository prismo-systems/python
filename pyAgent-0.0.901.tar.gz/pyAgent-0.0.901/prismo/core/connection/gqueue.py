#!/usr/bin/env python

__copyright__ = """
* Copyright (c) 2018 Prismo Systems . All rights reserved.
*
"""

__author__ = 'Ramesh Mani'

try:
    import cPickle as pickle
except:
    import pickle
import struct
import time
PROCMON_TYPE_APP_DATA   =        0x0102

# from prismo.metafile.protobuf.amon_msg_type_pb2 import app_agent_data, AMON_MSG_TYPE_APP_AGENT_DATA_RSP
from google.appengine.api import taskqueue

header_packer = struct.Struct('!8s Q I I I I I I I I')
pm_context_struct = struct.Struct("!128s 32s 16s 16s 80s 32s 32s 32s 1s I")


class GAETaskQue(object):
    pid = 100  # need to get this from env

    def __init__(self, agent, connection_properties):
        self.queue_name = connection_properties['queue_name']
        # self._queue = True
        self._queue = taskqueue.Queue(name=self.queue_name)
        self.use_pickle = False
        self.agent = agent
        self.logger = self.agent.get_logger(__name__)

    def append(self, msg_envelope):
        t = None

        try:
            # print 'append message envelope to queue'
            if self._queue:
                if self.use_pickle:  # this is protobuf over tcp
                    message_serialized = pickle.dumps(msg_envelope, pickle.HIGHEST_PROTOCOL)  # using string.could use binary
                    message_serialized += '__#PRISMO_MESSAGE_END#__'
                    # self._connection.sendall(message_serialized)
                    t = taskqueue.Task(payload=message_serialized, method='PULL')
                    t_submitted = self._queue.add(t)
                    ms = str(t_submitted.was_enqueued)
                    if t_submitted.queue_name:
                        ms += " Q:" + t_submitted.queue_name
                    self.logger.debug('Successfully sent message to server task queue ')
                else:  # this is pickle over tcp
                    message_internal = repr(msg_envelope)
                    #####
                    packed_header = self.get_header(PROCMON_TYPE_APP_DATA, len(message_internal))
                    #####
                    t_header = taskqueue.Task(payload=packed_header, method='PULL')
                    t_body = taskqueue.Task(payload=message_internal, method='PULL')
                    # print 'Task created :'
                    t_h_submitted = self._queue.add(t_header)
                    t_b_submitted = self._queue.add(t_body)
                    # if t_h_submitted.was_enqueued and t_b_submitted.was_enqueued:
                    #     self.logger.debug('Successfully sent message to server task queue ')
                    # else:
                    #     self.logger.debug('Failed to enqueue message to server task queue')
            else:
                # print 'Failed to send message to server task queue is not available'
                self.logger.error('Failed to send message to server task queue is not available ' )
        except Exception as e:
            self.logger.error('Exception while sending  message to server:' + str(e))
            self.logger.error("exception:" + t.payload + t.name + t.queue_name + t.was_enqueued)
            raise e

    def get_header(self, m_type, length):
        """
        :param m_type: PROCMON_TYPE_SYSINFO
        :param length: length of the packed data being sent
        :param process_id:
        :return:
        """
        epoch_time = time.time()
        header = ('AAAABBBB', epoch_time, m_type, length, 0, 0, self.pid, 0, 0, 0)
        return header_packer.pack(*header)
