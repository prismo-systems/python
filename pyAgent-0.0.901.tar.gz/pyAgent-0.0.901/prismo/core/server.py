#!/usr/bin/env python

__copyright__ = """
* Copyright (c) 2018 Prismo Systems . All rights reserved.
*
"""

__author__ = 'Ramesh Mani'

from prismo.util.pattern import Singleton
import time
from prismo.util.prismothreading import ThreadBase
from collections import deque
from prismo.constants import MAX_DATA_QUEUE_LENGTH, CONNECTION_RETRY_INTERVAL, CONNECTION_STATUS_MONITOR_INTERVAL,\
    MSG_INTERVAL, MSG_CHUNK_SIZE
from prismo.constants import MODULE, CLASS, METHOD, NAME, TYPE_SERVICE
from prismo.core.services import ServiceStatus
from prismo.core.message import MessageEnvelope
from prismo.core.transaction import PrismoThreadLocalStack
import importlib
import logging
import sys


class ConnectionStatus(object):
    DISCONNECTED = 0
    CONNECTING = 1
    CONNECTED = 2
    ERROR = 3

    def __init__(self):
        pass


class ServerConnectionEventListener(object):
    def __init__(self):
        pass

    def connection_status_changed(self, status):
        pass


# all server and data is managed by this administrator
class ServerAdministrator(Singleton):
    def __init__(self, agent, supports_py_threads):
        self.agent = agent
        self.agent_registration = None
        self.supports_py_threads = supports_py_threads
        self.connection_properties = agent.server_connection_properties;
        self.server_connection = None
        self.data_queue = None
        self.queue_processor = None
        self.connection_listeners = []
        self.connection_status_monitor = None
        self.logger = agent.get_logger(__name__)
        self.logger.info('ServerAdmin- App Entity' + agent.get_application_entity())
        MessageEnvelope.application_entity = agent.get_application_entity()

    def initialize(self):
        if self.supports_py_threads:
            # print ('ServerAdministrator.initialize')
            self.logger.info("Starting server admin workers")
            self.data_queue = DataQueue(self.agent, self)
            self.server_connection = ServerConnection(self.agent, self, 15, 3)
            self.connection_status_monitor = ConnectionStatusMonitor(self.agent, self)
            self.queue_processor = DataQueueWorker(self.agent, self, self.server_connection, self.data_queue, MSG_INTERVAL,
                                                   MSG_CHUNK_SIZE)
            self.server_connection.start()
            self.connection_status_monitor.start()
            self.queue_processor.start()
        else:
            # Todo - Should provide a mechanism to plug in the custom queue. In this case its google taskqueue
            # but it should be possible to do this with a  configuration
            from prismo.core.connection.gqueue import GAETaskQue
            self.data_queue = GAETaskQue(self.agent, self.connection_properties)

    def update_agent_registration(self, agent_registration):
        self.logger.debug('Updated agent registration in ServerAdministrator')
        self.agent.set_agent_registration(agent_registration)
        self.agent_registration = agent_registration

    def notify_connection_listeners(self, status):
        try:
            for listener in self.connection_listeners:
                listener.connection_status_changed(status)
        except Exception as e:
            self.logger.debug('Error executing event listeners: ' + str(e))

    def set_connection_status(self, status):
        self.connection_status_monitor.set_connection_status(status)

    def register_connection_listener(self, listener):
        self.connection_listeners.append(listener)

    def get_data_queue(self):
        return self.data_queue

    def send_message(self, message_type, message_element):
        # print ('sending message type: ' + str(message_type))
        # print ('sending message element: ' + str(message_element))
        message_envelope = MessageEnvelope(message_type)
        message_envelope.add_payload(message_element)
        # message_serialized = pickle.dumps(message_envelope, pickle.HIGHEST_PROTOCOL)  # using string not binary..
        self.data_queue.append(message_envelope)


class ConnectionStatusMonitor(ThreadBase):
    def __init__(self, agent, server_administrator):
        super().__init__(name='connection_status_worker', target=self.process)
        self.agent = agent
        self.server_administrator = server_administrator
        self.connection_status = []
        self.setDaemon(True)
        self.logger = agent.get_logger(__name__)

    def process(self):
        while True:
            try:
                for status in self.connection_status:
                    self.server_administrator.notify_connection_listeners(status)
                self.connection_status = []
            except Exception as e:
                self.logger.error(str(e))
            finally:
                time.sleep(CONNECTION_STATUS_MONITOR_INTERVAL)

    def set_connection_status(self, status):
        self.connection_status.append(status)


# This maintains a thread that establishes the connection .
# if the connection is dropped or has an exception,
# this object will be notified as it is a ServerConnectionEventListener
# it reconnects again
class ServerConnection (ServerConnectionEventListener):
    def __init__(self, agent, server_administrator, wait_period, retry_count):
        super().__init__()
        self.agent = agent
        self.server_administrator = server_administrator
        self.retry_wait = wait_period
        self.retry_count = retry_count
        self.control_conn = None
        self.conn = None
        self.thread = ThreadBase(name='server_connection', target=self.connect, kwargs={'server_con': self})
        self.thread.setDaemon(True)
        self.wait_before_connect = False
        self.logger = agent.get_logger(__name__)
        self._reconnect = True
        server_administrator.register_connection_listener(self)
        self.alive_counter = 0
        self.agent_registration = None

    def start(self):
        if self.thread is None or not self.thread.is_alive():
            self.thread = ThreadBase(name='server_connection', target=self.connect, kwargs={'server_con': self})
            self.thread.setDaemon(True)
            self._reconnect = True
        try:
            self.thread.start()
        except Exception:
            # print ('Error in connection!!!')
            e1 = sys.exc_info()[0]
            self.logger.error('Exception raised is:' + str(e1))

    def connect(self, server_con=None):
        while True:
            try:
                if server_con:
                    if server_con._reconnect:
                        server_con.connect_internal()
                else:
                    self.logger.error('Server Connection was null!!')
                    if self._reconnect:
                        self.connect_internal()
            finally:
                time.sleep(30)

    def connect_internal(self):
        try:
            if self.wait_before_connect:
                self.logger.debug('Server disconnected. Retry in 60 seconds..')
                time.sleep(CONNECTION_RETRY_INTERVAL)
            while self.retry_count > 0:
                if self._do_connect():
                    self.server_administrator.set_connection_status(ConnectionStatus.CONNECTED)
                    self.logger.info('successfully connected')
                    break
                else:
                    self.retry_count -= 1
                    time.sleep(self.retry_wait)

        except Exception as e:
            self.logger.info('Connection Exception :' + str(e))
            # import traceback
            # traceback.print_exc(file=sys.stdout)
            t, v, tb = sys.exc_info()
            if t and v and tb:
                self.logger.error("Connection Exception Details :" + str(t) + " -- " + str(v))
            self.server_administrator.set_connection_status(ConnectionStatus.ERROR)

    def register_agent(self):
        # This registers the agent with the collector. If this agent already has an agent ID then it uses it to fetch
        # the collector IP and certificates for the connection.
        # :return:
        from prismo.core.connection.controller import ControllerConnection
        ctrl_con = ControllerConnection(self.agent, self.agent_registration,
                                        self.server_administrator.connection_properties['agent_cert_file_path'],
                                        self.server_administrator.connection_properties['controller_host'],
                                        self.server_administrator.connection_properties['controller_port'])
        if ctrl_con.connect():
            self.agent_registration = ctrl_con.register_agent()
            ctrl_con.close_connection()
            # lets save the agent and collector properties
            self.server_administrator.update_agent_registration(self.agent_registration)
            return True
        return False

    def _do_connect(self):
        # actual connection code here

        self.logger.info('Connecting to Controller' + self.server_administrator.connection_properties['controller_host']
                         + ':' + str(self.server_administrator.connection_properties['controller_port']))
        if not self.register_agent():
            return False
        # lets wait a bit
        time.sleep(15)

        self.logger.debug('Connecting to collector ' + self.server_administrator.agent_registration.host + ':'
                          + str(self.server_administrator.agent_registration.port))
        # import the ClientSocketConnection here instead of top of the file so that the module importing
        # this one can be agnostic to the connection type (socket based or google task queue based etc)
        from prismo.core.connection.tcp import CollectorChannel, CollectorSocket, CollectorAddress, \
            ControlConnectionThread

        control_channel_addr = CollectorAddress(self.server_administrator.agent_registration, CollectorChannel.Control)
        self.control_conn = CollectorSocket(self.agent, control_channel_addr)
        control_thread = ControlConnectionThread(self.agent, self.control_conn)
        control_thread.start()
        while not self.control_conn.ready:
            time.sleep(1)

        data_channel_addr = CollectorAddress(self.server_administrator.agent_registration, CollectorChannel.Data)
        self.conn = CollectorSocket(self.agent, data_channel_addr)
        if self.conn.connect():
            self.conn.setup_socket()
            self.conn.seq = 0
            while not self.conn.ready:
                time.sleep(1)
            self._reconnect = False
            return True
        else:
            return False

    # def _do_connect_v1(self):
    #     # actual connection code here
    #     self.logger.info('Connecting to' + self.server_administrator.connection_properties['host'] + ':'
    #                      + self.server_administrator.connection_properties['data_port'])
    #     # import the ClientSocketConnection here instead of top of the file so that the module importing
    #     # this one can be agnostic to the connection type (socket based or google task queue based etc)
    #     from prismo.core.connection.tcp import ClientSocketConnection
    #     self.conn = ClientSocketConnection(self.agent, self.server_administrator.connection_properties)
    #     if self.conn.connect():
    #         self._reconnect = False
    #         return True
    #     else:
    #         return False

    # this is executed by the connection monitor thread, so keep it short here.
    # This cares only if connecttion is dropped. Else has nothing to do
    def connection_status_changed(self, status):
        if status is not ConnectionStatus.CONNECTED:
            self.wait_before_connect = True
            if self.thread is not None and self.thread.is_alive():
                self.logger.info("Connection will reconnect in the existing thread")
                self._reconnect = True
            else:
                self.logger.info("Connection will reconnect in a new thread")
                self.start()

    # this will perform a dual purpose
    # send keep alive
    # also check if it needs to reconnect. The reconnect is set by the watcher thread
    def send_keep_alive(self):
        try:
            self.conn.send_keep_alive()
            if self.logger.isEnabledFor(logging.DEBUG):
                self.logger.debug('Sending Keep Alive- ' + self.agent.get_agent_id() + "  :" + str(self.alive_counter))
            self.alive_counter += 1

        except Exception as e:
            import os
            pid = os.getpid()
            self.logger.error("Data Connection- Keep alive failure- PID:" + str(pid) + " AgentId: "+ self.agent.get_agent_id() + "  :" + str(self.alive_counter) + str(e))
            self.server_administrator.set_connection_status(ConnectionStatus.DISCONNECTED)
            self.alive_counter = 0

    # this is called by the DataQueueWorker thread. So in case connection is lost, it
    # simply fires the connection lost event. The connection thread monitor will
    # listen for the event and create the connection thread which will retry connection.
    def send(self, msg):
        try:
            if self.logger.isEnabledFor(logging.DEBUG):
                self.logger.debug('Sending Msg: ' + str(msg))
            # self.conn.send(msg)
            self.conn.send_data(msg)
        except Exception as e:
            self.logger.error(str(e))
            self.server_administrator.set_connection_status(ConnectionStatus.DISCONNECTED)


# Connection status aware Queue. The underlying deque is thread safe
# The queue is bounded such that when it is full, the oldest item is dropped.
class DataQueue(ServerConnectionEventListener):
    def __init__(self, agent, server_administrator):
        super().__init__()
        self.agent = agent
        self.server_administrator = server_administrator
        self.shouldQueue = False
        self.queue = deque(maxlen=MAX_DATA_QUEUE_LENGTH)
        self.logger = agent.get_logger(__name__)
        self.server_administrator.register_connection_listener(self)

    def append(self, item):
        if self.shouldQueue:
            self.queue.appendleft(item)

    def pop(self):
        if not self.shouldQueue:
            return None
        try:
            return self.queue.pop()
        except IndexError:
            # don' care..
            return None

    def connection_status_changed(self, status):
        if status is ConnectionStatus.CONNECTED:
            self.queue.clear()
            self.shouldQueue = True
        elif status is ConnectionStatus.DISCONNECTED or status is ConnectionStatus.ERROR:
            self.shouldQueue = False
            self.queue.clear()


# this sends data to the server if the connection is alive
class DataQueueWorker(ThreadBase, ServerConnectionEventListener):
    def __init__(self, agent, server_administrator, server_connection, data_queue, interval, chunk_size):
        super().__init__(name='data_queue_worker', target=self.process)
        self.agent = agent
        self.server_administrator = server_administrator
        self.server_connection = server_connection
        self.data_queue = data_queue
        self.interval_wait = interval
        self.chunk_size = chunk_size
        self.skip_processing = True
        self.setDaemon(True)
        self.logger = agent.get_logger(__name__)
        server_administrator.register_connection_listener(self)
        self.keep_alive_counter = 0

    def connection_status_changed(self, status):
        if status is ConnectionStatus.CONNECTED:
            self.skip_processing = False
        else:
            self.skip_processing = True

    # the messages should be in envelopes and should decide based on the header as to the type
    # and send according to different targets (sheets for now)
    def process(self):
        prismo_thread_stack = PrismoThreadLocalStack()
        prismo_thread_stack.set_should_skip(True)
        while True:
            try:
                if not self.skip_processing:
                    msg_array = []
                    for i in range(self.chunk_size):
                        msg = self.data_queue.pop()
                        if msg is None:
                            break
                        msg_array.append(msg)
                    if len(msg_array) > 0:
                        if self.logger.isEnabledForTrace():
                            self.logger.trace(' Message Count :' + str(len(msg_array)))
                            self.logger.trace('Message Type for 0: ' + repr(msg_array[0].header))
                        # print ('Message Type for 0: ' + repr(msg_array[0].header))
                        # print ('Message payload for 0: ' + repr(msg_array[0].payload))
                        self.server_connection.send(msg_array)
                        # TODO !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!s
                        # TODO UNCOMMENT the line above when ready to sent data!!!!!!!
                        # TODO Right now it disconnects the connection from the collector
                    self.keep_alive_counter += 1
                    if self.keep_alive_counter > 150:
                        self.server_connection.send_keep_alive()
                        self.keep_alive_counter = 0
            except Exception as e:
                self.logger.error('Exception sending data to server:' + str(e))
                self.server_administrator.set_connection_status(ConnectionStatus.ERROR)
            finally:
                time.sleep(self.interval_wait)


# all services  are managed by this administrator. The services are executed
# in a separate thread managed by the Service Administrator
#
class ServiceAdministrator(Singleton):
    def __init__(self, agent, service_definitions):
        self.agent = agent
        self.service_definitions = service_definitions
        self.services = {}
        self.logger = agent.get_logger(__name__)
        self.service_worker = ServiceWorker(agent, self)

    def initialize(self):
        for service in self.service_definitions:
            # lets load the service module, instantiate the class
            try:
                self.logger.info('Loading extension service: ' + service.get(NAME))
                # load here
                service_code = self._load_service(service)
                instance = service_code()
                instance.status = ServiceStatus.loaded
                if instance is not None:
                    self.services[service.get(NAME)] = instance
            except Exception as e:
                self.logger.error('Error loading extension service: ' + str(e))
            finally:
                self.logger.info('Finished loading extension services')
        # start services
        try:
            self.logger.debug('Starting extension services')
            self.service_worker.start()
        except Exception as e:
            self.logger.error('Error starting extension service: ' + str(e))

    def get_service_names(self):
        return self.services.keys()

    def get_service(self, name):
        return self.services.get(name)

    def shutdown_service(self, name):
        service = self.services.get(name)
        if service is not None:
            service.status = ServiceStatus.shutdown
            service.shutdown()

    def _load_service(self, service_definition):
        # this will load the service
        try:
            # load the service class
                code = getattr(importlib.import_module(service_definition[MODULE]), service_definition[CLASS], False)
                if not code:
                    self.logger.error('Failed to load extension service ' + service_definition[NAME])
                    return None
                return code   # Todo pass parameters from config to services
        except Exception as e:
            self.logger.error('Failed to load extension service ' + service_definition[NAME])
            self.logger.error(str(e))


class ServiceWorker(ThreadBase):
    def __init__(self, agent, service_administrator):
        super().__init__(name='service_worker', target=self.process)
        self.agent = agent
        self.service_administrator = service_administrator
        self.logger = agent.get_logger(__name__)
        self.setDaemon(True)

    def process(self):
        services = self.service_administrator.get_service_names()
        for name in services:
            service = self.service_administrator.get_service(name)
            if service is not None and service.status is ServiceStatus.loaded:
                try:
                    self.logger.debug('Starting extension service :' + name)
                    service.status = ServiceStatus.started
                    service.start(self.agent)
                except Exception as e:
                    self.logger.error('Exception starting extension service - ' + name + str(e))
                self.logger.debug('Finished starting extension services')
