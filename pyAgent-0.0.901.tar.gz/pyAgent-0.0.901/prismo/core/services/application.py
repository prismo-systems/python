#!/usr/bin/env python

__copyright__ = """
* Copyright (c) 2018 Prismo Systems . All rights reserved.
*
"""

__author__ = 'Ramesh Mani'

from prismo.core.services import ServiceBase, ServiceStatus
from prismo.core.message import MessageType, MessageElementType, MessageBodyElement
from prismo.constants import INVENTORY_SERVICE_INTERVAL_KEY
import time
import sys
import json


class InventoryService(ServiceBase):
    def __init__(self):
        super().__init__()
        self.parameters = {INVENTORY_SERVICE_INTERVAL_KEY: 5000}  # should get from config loading time
        self.modules = []
        self.server_administrator = None

    # TODO This needs to do the task in a separate thread.
    # TODO Its executing in the agent service worker thread as of now.
    # TODO This will hold up multiple services from executing until this finishes.
    def start(self, agent):
        logger = agent.get_logger(__name__)
        logger.debug('InventoryService - start')
        self.server_administrator = agent.get_server_administrator()
        wait_time = self.parameters[INVENTORY_SERVICE_INTERVAL_KEY]/1000  # its in ms
        while self.status is ServiceStatus.started:
            try:
                self.execute(agent)
            except Exception as e:
                logger.error('Exception executing InventoryService: ' + str(e))
            finally:
                time.sleep(wait_time)

    def shutdown(self, agent):
        logger = agent.get_logger(__name__)
        logger.debug('InventoryService - shutdown')

    def execute(self, agent):
        new_modules = []
        for key in sys.modules.keys():
            mod = sys.modules.get(key)
            if mod is not None and mod.__name__ not in self.modules:
                self.modules.append(mod.__name__)
                new_modules.append(mod.__name__)
        if len(new_modules) > 0:
            # we need to send these to the server
            msg = self.create_application_inventory_message(new_modules)
            # import os
            # print 'Application Inventory: ' + str(os.getpid()) + ": " + repr(msg)
            self.server_administrator.send_message(MessageType.application, msg)

    @classmethod
    def create_application_inventory_message(cls, module_list):
        msg = ApplicationInventory()
        msg.add_modules(module_list)
        return msg


# Should implement __slots__ and getstate and setstate
# http://book.pythontips.com/en/latest/__slots__magic.html
# https://docs.python.org/2/library/pickle.html#object.__getstate__
class ApplicationInventory(MessageBodyElement):
    __slots__ = ['modules']

    def __init__(self):
        super().__init__(MessageElementType.application)
        self.modules = []

    def add_modules(self, modules):
        self.modules = modules

    def __getstate__(self):
        return {'modules': self.modules}

    def __setstate__(self, state):
        self.modules = state['modules']

    def __str__(self):
        return '"app_inventory": {"Modules":' + json.dumps(self.modules) + '}'

    def __repr__(self):
        return '"app_inventory": {"Modules":' + json.dumps(self.modules) + '}'
