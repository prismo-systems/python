#!/usr/bin/env python

__copyright__ = """
* Copyright (c) 2018 Prismo Systems . All rights reserved.
*
"""

__author__ = 'Ramesh Mani'

from prismo.core.probes import ProbeBase


class GenericProbe(ProbeBase):
    def __init__(self, agent):
        super().__init__(agent)
        self.agent = agent
        self.logger = agent.get_logger(__name__)

    def enter(self, instruction, context):
        if self.logger.isEnabledForTrace():
            self.logger.trace('GenericProbe - enter')

    def exit(self, instruction, context):
        if self.logger.isEnabledForTrace():
            self.logger.trace('GenericProbe - exit')
        sig_type = context.get_signature_type()
        if sig_type is None:
            context.set_signature_type('Generic')  # wil be treated as exit point.  and a default entry point


