#!/usr/bin/env python
__copyright__ = """
* Copyright (c) 2018 Prismo Systems . All rights reserved.
*
"""

__author__ = 'Ramesh Mani'

print ('start agent import')
from prismo.constants import PRINT_PREFIX, DEFAULT_LOG_FILENAME, LOGGING_ROOT, LOGGING_ROOT_DOT
from prismo.config.configutils import AgentConfig, InstrumentationConfig
from prismo.util.pattern import Singleton
print ('agent imp1')

from prismo.core.server import ServerAdministrator, ServiceAdministrator
print ('agent imp2')

from prismo.core.transaction import TransactionAdministrator, TransactionStartEventListener, \
    TransactionFinishEventListener, ExternalCorrelationEventListener
print ('agent imp3')

import logging.handlers
import os
print ('agent imp3.5')

import prismo
print ('agent imp4')
from prismo.util.prismothreading import ThreadBase
from prismo.core.message import MessageEnvelope
print ('agent imports')
# Need an AgentShim which has the instance of the actual methods invoked thru instrumentation.
# The AgentShim should protect the application from all agent failures.
# print ('all imported')
import uuid

# import traceback
# import datetime
# import os


class AgentStatus:
    initializing = 1
    ready = 2
    error = 3

    def __init__(self):
        pass


class PyAgent(Singleton):
    # easiest and cheapest (startup bubble) to check version
    _version = '0.0.900'
    _id = uuid.uuid4().hex
    app_entity = "Default Entity"
    agent_registration = None

    def __init__(self, app_entity):
        import sys
        print("Agent.__init__")
        # sys.path.append('C:\Program Files\JetBrains\PyCharm 2018.1.4\debug-eggs\pycharm-debug.egg')
        # import pydevd
        # pydevd.settrace('localhost', port=9000, stdoutToServer=True, stderrToServer=True)

        # print (PRINT_PREFIX + "Agent Instance Created!")
        self.app_entity = app_entity
        self.status = AgentStatus.initializing
        # set up logger
        logging.addLevelName(PrismoLogger.LEVEL_TRACE, PrismoLogger.LEVEL_TRACE_NAME)
        logging.setLoggerClass(PrismoLogger)
        self.logger = logging.getLogger(LOGGING_ROOT)
        ch = logging.StreamHandler(sys.stdout)
        self.logger.addHandler(ch)
        # print ('Agent logger set')
        self.logger.propagate = False   # important as we don't want it to go to the system root

        self.agent_config = AgentConfig(self)
        # print ('config object initialized')
        self.agent_config.load_agent_config()
        # print (PRINT_PREFIX + 'config loaded')

        log_file_path = self.agent_config.get_property(KAgentProperties.AGENT_LOG_FILE_PATH,
                                                       KAgentProperties.AGENT_LOG_FILE_PATH_DEFAULT)
        log_file_max_bytes = self.agent_config.get_property(KAgentProperties.AGENT_LOG_FILE_MAX_BYTES,
                                                            KAgentProperties.AGENT_LOG_FILE_MAX_BYTES_DEFAULT)
        log_backup_count = self.agent_config.get_property(KAgentProperties.AGENT_LOG_FILE_BACKUP_COUNT,
                                                          KAgentProperties.AGENT_LOG_FILE_BACKUP_COUNT_DEFAULT)
        log_level = self.agent_config.get_property(KAgentProperties.AGENT_LOG_LEVEL,
                                                   KAgentProperties.AGENT_LOG_LEVEL_DEFAULT)
        log_level = str(log_level).rstrip('\r')
        log_format = self.agent_config.get_property(KAgentProperties.AGENT_LOG_FORMAT,
                                                    KAgentProperties.AGENT_LOG_FORMAT_DEFAULT)
        # self.logger = logging.getLogger(LOGGING_ROOT)
        # self.logger.propagate = False   # important as we don't want it to go to the system root

        # if not os.path.isdir(os.path.dirname(os.path.abspath(log_file_path))):
        #     os.makedirs(os.path.dirname(os.path.abspath(log_file_path)), 0755)

        # log_handler = logging.handlers.RotatingFileHandler(log_file_path,
        #                                                    maxBytes=log_file_max_bytes,
        #                                                    backupCount=log_backup_count)
        # log_formatter = logging.Formatter(log_format)
        # self.logger.addHandler(log_handler)
        # log_handler.setFormatter(log_formatter)
        self.logger.setLevel(log_level)
        msg = self.get_agent_startup_log_message()
        self.logger.info(msg)
        self.instrumentation_enabled = self.agent_config.get_property(
            KAgentProperties.AGENT_INSTRUMENTATION_ENABLE, KAgentProperties.AGENT_INSTRUMENTATION_ENABLE_DEFAULT)
        # print ("Instrumentation " + str(self.instrumentation_enabled))
        if not self.instrumentation_enabled or self.instrumentation_enabled == "False":
            self.logger.warn("Prismo Agent Instrumentation is disabled. No probes will be added to the application")
        self.instrumentation_config = InstrumentationConfig(self)
        self.instrumentation_config.load_instrumentation_config()
        # setup process fork.. maybe do it before the instrumentation config is read?
        from prismo.core.system import ProcessForkHook, ProbeAdministrator, ModuleAdministrator, Instrumentation
        ProcessForkHook.enable(self)
        self.probe_administrator = ProbeAdministrator(self, self.instrumentation_config)
        self.module_administrator = ModuleAdministrator(self, self.probe_administrator)
        self.instrumentation = Instrumentation(self, self.module_administrator, self.probe_administrator)
        self.transaction_administrator = TransactionAdministrator(self)
        app_entity_from_config = self.agent_config.get_property(KAgentProperties.APP_ENTITY_FROM_CONFIG)
        if app_entity_from_config and app_entity_from_config == "True":
            self.app_entity = self.agent_config.get_property(KAgentProperties.APP_ENTITY)
        self.logger.info("Application Entity: " + self.app_entity)
        # print ("Host :" + str("_" + self.agent_config.get_property(KAgentProperties.CONNECTION_PROPERTIES_HOST)))
        cert_file_path = self.agent_config.get_property(KAgentProperties.AGENT_CERT_FILE)
        if not cert_file_path:
            import prismo.config as config
            cert_file_path = os.path.join(os.path.dirname(os.path.realpath(config.__file__)), 'certfile.crt')
        self.server_connection_properties = {
            'host': self.agent_config.get_property(KAgentProperties.CONNECTION_PROPERTIES_HOST),
            'data_port': self.agent_config.get_property(KAgentProperties.CONNECTION_PROPERTIES_DATA_PORT),
            'command_port': self.agent_config.get_property(KAgentProperties.CONNECTION_PROPERTIES_COMMAND_PORT),
            'controller_host': self.agent_config.get_property(KAgentProperties.CONNECTION_PROPERTIES_CONTROLLER_HOST),
            'controller_port': self.agent_config.get_property(KAgentProperties.CONNECTION_PROPERTIES_CONTROLLER_PORT),
            'agent_cert_file_path': cert_file_path,
            'queue_name': 'prismo-agent-queue'}
        self.include_host_id = self.agent_config.get_property(KAgentProperties.AGENT_INCLUDE_CONTAINER_ID)
        if self.include_host_id is None or self.include_host_id == 'true':
            self.logger.debug("Container ID is enabled")
            MessageEnvelope.set_container_id(True)
        from prismo.util.prismothreading import ThreadBase
        self.server_administrator = ServerAdministrator(self, ThreadBase.supports_py_threads)
        if ThreadBase.supports_py_threads:
            self.service_administrator = ServiceAdministrator(self, self.instrumentation_config.get_service_definitions())
        else:
            self.service_administrator = None

    def get_agent_id(self):
        """This identifies this instance of the application agent and is used by the collector to pair the two
        connections (Control and Data)"""
        if self.agent_registration:
            return self.agent_registration.agent_id
        else:
            # print ('Agent_Registration was None')
            return self._id

    def get_agent_ip(self):
        if self.agent_registration:
            return self.agent_registration.address
        else:
            # print ('Agent_Registration was None')
            return '127.0.0.1'

    def set_agent_registration(self, agent_registration):
        self.agent_registration = agent_registration

    def get_application_entity(self):
        return self.app_entity

    def start_services(self):
        # start server connection manager here. This will will start separate thread
        #
        self.server_administrator.initialize()
        if self.service_administrator:
            self.service_administrator.initialize()
        self.instrumentation.initialize_import_hook()
        if self.instrumentation_enabled:
            self.instrumentation.enable()
        self.transaction_administrator.register_start_listener(TransactionStartEventListener('Start_Listener-1', self))
        self.transaction_administrator.register_finish_listener(TransactionFinishEventListener('Finish_Listener-1', self))
        self.transaction_administrator.register_external_correlation_listener(
            ExternalCorrelationEventListener('Finish_Listener-1', self))

        # once all services are ready, change the status of the agent as ready
        self.status = AgentStatus.ready

    # Quite a few things to reinitialize.
    # ToDO : server_administrator, tx_listeners, etc
    def initialize_forked_process(self):
        self.logger.info('Reinitializing services in forked process')
        _id = uuid.uuid4().hex
        self._id = uuid.uuid4().hex
        self.logger.info('Agent _ID: ' + self.get_agent_id())
        self.transaction_administrator.__init__(self)
        self.server_administrator.__init__(self, ThreadBase.supports_py_threads)
        self.service_administrator.__init__(self, self.instrumentation_config.get_service_definitions())
        self.server_administrator.initialize()
        self.service_administrator.initialize()
        self.module_administrator.__init__(self, self.probe_administrator)
        if not self.instrumentation.is_initialized():
            self.instrumentation.initialize_import_hook()
            # print ('Import hook reinitialized')
        if self.instrumentation_enabled:
            self.instrumentation.enable()
        self.transaction_administrator.register_start_listener(TransactionStartEventListener('Start_Listener-1', self))
        self.transaction_administrator.register_finish_listener(TransactionFinishEventListener('Finish_Listener-1', self))
        self.transaction_administrator.register_external_correlation_listener(
            ExternalCorrelationEventListener('Finish_Listener-1', self))

    def get_server_administrator(self):
        return self.server_administrator

    def close_logger(self):
        logging.shutdown(self.logger.handlers)

    def get_logger(self, module_name):
        # lets ensure it is a prismo decendant so that the same log handler is used
        if module_name is None:
            return self.logger
        # print ('Logger requested' + module_name)
        if str(module_name).startswith(LOGGING_ROOT_DOT):
            # we need to store these to change during fork as they belong to the agent
            return logging.getLogger(module_name)
        else:
            # should not allow this but lets return the agent module logger or a descendant
            # This is so that in case extensions (probes) are in a separate module and
            # are packaged separately, they the root may not be 'prismo'
            prismo_name = LOGGING_ROOT_DOT + module_name
            return logging.getLogger(prismo_name)

    def get_agent_startup_log_message(self):
        import sys
        import datetime
        space = '                                                     '
        msg = '-------------------------------------------------\n'
        msg += space
        msg += 'Prismo Python Agent\n'
        msg += space
        msg += 'Version: ' + self._version + '\n'
        msg += space
        msg += 'Python Version: ' + sys.version + '\n'
        msg += space
        msg += 'Agent startup time: ' + str(datetime.datetime.now()) + '\n'
        return msg


# custom level tracing to handle transaction logging
class PrismoLogger(logging.getLoggerClass()):

    LEVEL_TRACE = 5
    LEVEL_TRACE_NAME = 'TRACE'

    def __init__(self, logger_name):
        self.fetch_is_trace = True
        self.is_trace = None
        logging.Logger.__init__(self, name=logger_name)

    def trace(self, msg, *args, **kwargs):
        self.log(PrismoLogger.LEVEL_TRACE, msg, *args, **kwargs)

    def isEnabledForTrace(self):
        if self.fetch_is_trace:
            self.fetch_is_trace = False
            self.is_trace = self.isEnabledFor(PrismoLogger.LEVEL_TRACE)
            # patch this method to return straight
            import sys
            _module = sys.modules.get(__name__, None)
            if _module:
                _class = getattr(_module, 'PrismoLogger', None)
                if _class:
                    setattr(_class, 'isEnabledForTrace', self.is_enabled_for_trace)

        return self.is_trace

    def is_enabled_for_trace(self):
        return self.is_trace


class KAgentProperties:
    AGENT_CERT_FILE = 'prismo_agent_cert_file'
    CONNECTION_PROPERTIES_CONTROLLER_PORT = 'prismo_controller_port'
    CONNECTION_PROPERTIES_CONTROLLER_HOST = 'prismo_controller_host'
    AGENT_LOG_FILE_PATH = 'prismo.agent.log.file.path'
    AGENT_LOG_FILE_PATH_DEFAULT = os.path.join(os.path.dirname(os.path.realpath(prismo.__file__)), DEFAULT_LOG_FILENAME)
    AGENT_LOG_FILE_MAX_BYTES = 'prismo.agent.log.file.max_bytes'
    AGENT_LOG_FILE_MAX_BYTES_DEFAULT = 1048576
    AGENT_LOG_FILE_BACKUP_COUNT = 'prismo.agent.log.backup.count'
    AGENT_LOG_FILE_BACKUP_COUNT_DEFAULT = 5
    AGENT_LOG_LEVEL = 'prismo_agent_log_level'
    AGENT_LOG_LEVEL_DEFAULT = logging.INFO
    AGENT_LOG_FORMAT = 'prismo.agent.log.format'
    AGENT_LOG_FORMAT_DEFAULT = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    CONNECTION_PROPERTIES_HOST = 'prismo_collector_host'
    CONNECTION_PROPERTIES_DATA_PORT = 'prismo.collector.data.port'
    CONNECTION_PROPERTIES_COMMAND_PORT = 'prismo.collector.command.port'
    APP_ENTITY = 'prismo_app_entity'
    APP_ENTITY_FROM_CONFIG = "prismo_app_entity_from_config"
    AGENT_INSTRUMENTATION_ENABLE = "prismo_instrumentation_enabled"
    AGENT_INSTRUMENTATION_ENABLE_DEFAULT = True
    AGENT_INCLUDE_CONTAINER_ID = "prismo_include_host_id"

    def __init__(self):
        pass
