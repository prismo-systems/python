#!/usr/bin/env python
__copyright__ = """
* Copyright (c) 2018 Prismo Systems . All rights reserved.
*
"""

__author__ = 'Ramesh Mani'


class ThreadSupport(object):
    thread_class = None
    supports_py_threads = False

    def __init__(self, thread_class, py_thread):
        ThreadSupport.thread_class = thread_class
        ThreadSupport.supports_py_threads = py_thread
